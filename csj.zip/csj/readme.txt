Open Mysql workbench
create user with username as 'root' and password as 'root'
Run the mysql.sql in Mysql Workbench. (This file create database and table)
Run the mongoDb
Create db with name : 'smartPortableReview' in mongodb
Create Collection 'review' in mongodb
