import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class DeleteProductServlet extends HttpServlet 
{
    protected void deleteProduct(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String productId = request.getParameter("prodID");
        if(productId != null && productId.length() != 0) 
        {
            productId = productId.trim();
        }
        
        ServletContext sc =request.getSession().getServletContext();
        BufferedReader buffReader = new BufferedReader(new FileReader(sc.getRealPath("productDetailList.txt")));

        ArrayList<ProductDescription> elementList = new ArrayList<ProductDescription>();
        String readInput;
        while((readInput = buffReader.readLine()) != null)
        {
            ProductDescription pds = new ProductDescription();
            ProductDataSet.setData(readInput,pds);
            elementList.add(pds);
        }
        buffReader.close();

        ProductDescription ds = new ProductDescription() ;

        for(ProductDescription element : elementList)
        {
            if(element.getID() == Integer.parseInt(productId))
            {
                ds = element ;
                System.out.println("Find");
            }
        }
        
        elementList.remove(ds);
        PrintWriter writer = new PrintWriter(sc.getRealPath("productDetailList.txt"));
        ConvertDStoString cds = new ConvertDStoString();
        for(ProductDescription pds : elementList){
            String line = cds.convertdstostring(pds);
            writer.print(line);
            writer.print("\n");
        }
        writer.close();
        showPage(response, "Product has been Deleted successfully");
    }

    protected void showPage(HttpServletResponse response, String message)
    throws ServletException, java.io.IOException {
        response.setContentType("text/html");
        java.io.PrintWriter pw = response.getWriter();
        CommonUtilities cu  = new CommonUtilities();
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        pw.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portable - Add Product</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            cu.getHeader()+
            "<nav>"+
            "<ul>"+
            "<li class='start selected'><a href='AdminServlet'>Home</a></li>"+
            "<li class=''><a href='login.html'>Sign Out</a></li>"+
            "</ul>"+
            "</nav>"+
            "<div id=\"body\">"+
            "<section id=\"content\">"+
            "<p>" + message + "</p>"+
            "<article>"+
            "</section>"+
            cu.getAdminLeftNav()+
            "<div class=\"clear\"></div>"+
            "</div>"+	
            cu.getFooter()+
            "</div>"+		            
            "</body>"+
            "</html>");
        pw.close();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        deleteProduct(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        deleteProduct(request, response);
    }
}