import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class DeleteCartItemServlet extends HttpServlet {

    protected void processPage(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
         response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String prodID = request.getParameter("deleteID");

        HttpSession session = request.getSession();
        cart shoppingCart;
        shoppingCart = (cart) session.getAttribute("cart");
        shoppingCart.deleteFromCart(prodID);
        session.setAttribute("cart", shoppingCart);
        shoppingCart = (cart) session.getAttribute("cart");
        CommonUtilities cu = new CommonUtilities();
        HashMap<String, List<String>> items = shoppingCart.getCartItems();
        int Cartsize = items.size();
        System.out.println(Cartsize);
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portable</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            " <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">"+
            "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>"+
            "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            cu.getHeader()+
            "<div ALIGN=RIGHT>"+
             "<a  href=\"#\" class=\"btn btn-info btn-lg\">"+
             "<span class=\"glyphicon glyphicon-shopping-cart\"></span>"+ Cartsize+ 
             "</a>"+
             "</div>"+
            //"<h2 ALIGN=RIGHT>Cart("+Cartsize+")<h2>"+
            "<table class='table'>"+
            "<tr>"+
            "<th>ProductID</th>"+
            "<th>Product Name</th>"+
            "<th>Price</th>"+
            "<th>Category</th>"+
            "<th></th>"+
            "</tr>");
            for (Map.Entry<String, List<String>> entry : items.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();
            out.println("<tr>");
            out.println("<td>"+values.get(0)+"</td>");
            out.println("<td>"+values.get(1)+"</td>");
            out.println("<td>"+values.get(2)+"</td>");
            out.println("<td>"+values.get(3)+"</td>");
            out.println("<td><form method = 'get' action = '/csj/DeleteCartItemServlet'><input type='hidden' name='deleteID' value='"+key+"'><input class = 'submit-button' type = 'submit' name = 'deleteButton' value = 'Delete'></form></td>");
            out.println("</tr>");
            }
             out.println(
            "</table>"+
            "<a href='home.html'>Add more Products</a>"+
            "<div ALIGN=RIGHT>"+
            "<form class = 'submit-button' method = 'get' action = '/csj/Checkout'>"+
            "<input class = 'submit-button' type = 'submit'  value = 'Proceed To Checkout'>"+
            "</form>"+
            "</div>"+
            "</br></br>"+
            cu.getAccessory()+
           
            cu.getFooter()+
            "</div>"+
            "</body>"+
            "</html>");
        }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    }
}
