import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class LoginServlet extends HttpServlet {
   
    protected Map userDetails = new HashMap(); 
    public void init() {
		//Enter username and password for admin and salesman
                userDetails.put("admin", "admin");
                userDetails.put("salesman", "salesman");
    }

    protected void processHTTPRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        String userid = request.getParameter("userid");
        String password = request.getParameter("password");
		String usertype = request.getParameter("usertype");
        ServletContext sc =request.getSession().getServletContext();
        sc.setAttribute("user", userid);
        System.out.println((String) sc.getAttribute("user"));
        Boolean flag = false;
        if(userid != null && userid.length() != 0) {
            userid = userid.trim();
        }
        if(password != null && password.length() != 0) {
            password = password.trim();
        }
        if(userid != null && password != null) 
        {
                String pwd = (String)userDetails.get(userid);
                if(pwd != null && pwd.equals(password)) {
                    //showPage(response, "Login Success!");
                    if(pwd.equals("admin") && usertype.equals("storemanager"))
                        response.sendRedirect("/csj/AdminServlet");
                    else if(pwd.equals("salesman") && usertype.equals("salesman"))
                        response.sendRedirect("/csj/SalesmanServlet");
                    else
                        showPage(response, "Please Enter Correct Username and Password");
                } 
                else 
                {
                    BufferedReader buffReader = new BufferedReader(new FileReader(sc.getRealPath("logindetails.txt")));
                    
                    String readInput;
                    while((readInput = buffReader.readLine()) != null)
                    {
                        String[] temp = readInput.split(":");
                        String pass[] = temp[1].split(",");

                        if(userid.equals(temp[0]) && password.equals(pass[0]))
                            flag = true;
                    }

                    if(flag)
                        response.sendRedirect("home.html");
                    else
                        showPage(response, "Login Failure!!! UserName or password is incorrect");
                }
        }
        else
        {
            showPage(response, "Please Enter Valid UserName and Password");
        }
    } 
    
    /**
     * Actually shows the <code>HTML</code> result page
     */
    protected void showPage(HttpServletResponse response, String message)
    throws ServletException, java.io.IOException {
        response.setContentType("text/html");
        java.io.PrintWriter out = response.getWriter();
        CommonUtilities cu = new CommonUtilities();
         String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portable - Login</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            cu.getHeader()+
            "<h2 style=\"color:red\">" + message + "</h2>"+
            "<a href='/csj/login.html'>Back to Login</a>"+
            cu.getFooter()+
            "</div>"+
            "</body>"+
            "</html>");
        out.close();
 
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processHTTPRequest(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processHTTPRequest(request, response);
    }
}
