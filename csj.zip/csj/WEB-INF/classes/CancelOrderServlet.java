import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class CancelOrderServlet extends HttpServlet 
{
    protected void deleteProduct(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
       
        ServletContext sc =request.getSession().getServletContext();
        BufferedReader buffReader = new BufferedReader(new FileReader(sc.getRealPath("PlacedOrder.txt")));

        ArrayList<ProductPlaceOrder> elementList = new ArrayList<ProductPlaceOrder>();
        String readInput;
        while((readInput = buffReader.readLine()) != null)
        {
        	ProductPlaceOrder pds = new ProductPlaceOrder();
            ProductDataSet.setData(readInput,pds);
            elementList.add(pds);
        }
        buffReader.close();

        
        
        elementList.clear();
        PrintWriter writer = new PrintWriter(sc.getRealPath("PlacedOrder.txt"));
        ConvertDStoString cds = new ConvertDStoString();
        for(ProductPlaceOrder pds : elementList){
            writer.print("");
        }
        writer.close();
        showPage(response, "Order has been Canceled successfully");
    }

    protected void showPage(HttpServletResponse response, String message)
    throws ServletException, java.io.IOException {
        response.setContentType("text/html");
        java.io.PrintWriter pw = response.getWriter();
        CommonUtilities cu  = new CommonUtilities();
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        pw.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portable - Add Product</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            cu.getHeader()+
            "<nav>"+
            "<ul>"+
            "<li class='start selected'><a href='home.html'>Home</a></li>"+
            "<li class=''><a href='login.html'>Sign Out</a></li>"+
            "</ul>"+
            "</nav>"+
            "<div id=\"body\">"+
            "<section id=\"content\">"+
            "<p>" + message + "</p>"+
            "<article>"+
            "</section>"+
            cu.getAdminLeftNav()+
            "<div class=\"clear\"></div>"+
            "</div>"+	
            cu.getFooter()+
            "</div>"+		            
            "</body>"+
            "</html>");
        pw.close();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        deleteProduct(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        deleteProduct(request, response);
    }
}