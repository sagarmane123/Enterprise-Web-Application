import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.bson.Document;

import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDBDataStoreUtilities {

	static DBCollection myReviews;
	static MongoCollection<Document> myReviewsCollection ;
	static MongoClient mongo;
	static String ALL = "ALL";
	static String GREATER = "GREATER";
	static String LESS = "LESS";
	static String EQUALS = "EQUALS";
	static String COUNT = "COUNT";
	
	public static void getConnection()
	{
		
		mongo = new MongoClient("localhost", 27017);
		DB db = mongo.getDB("smartPortableReview");
		myReviews= db.getCollection("review");
		
	}
	
	public static void destroyMongoConnection()
	{
		mongo.close();	
	}
	
	public static HashMap<String, Integer> getdata() {
		getConnection();
		HashMap<String, Integer> hm= new  HashMap<String, Integer>();
		DBObject dbObject;
		 DBCursor cursor = myReviews.find();
		 dbObject = cursor.next();
		 //  int rate = ((Number)dbObject.get("reviewRating")).intValue();
		//	System.out.println(rate);
		 while(cursor.hasNext()) {
			   dbObject = cursor.next();
			   String state = (String) dbObject.get("RetailerState");
			   int rate = ((Number)dbObject.get("reviewRating")).intValue();
			   System.out.println(state);
			   System.out.println(rate);
			   hm.put(state, rate);
			}
		 
		 Map<String, Integer> counts = new HashMap<String, Integer>();
		 for (String c : hm.keySet()) {
		     int value = counts.get(c) == null ? 0 : counts.get(c);
		     counts.put(c, value + 1);
		 }
		 System.out.println(counts);
		return hm;

	}
	
	public static void insertMongo(int productID,String productName, String prodCate,
			String prodPrice, String prodRetName,
			 String RetailerZip, String RetailerState, String RetailerCity, String productOnSale, String prodManfName, String ManfRebate,
			 String UserId, String UserAge, String UserGender, String UserOccupation,int reviewRating, String currDate, String reviewText) {
		try {
		getConnection();
		System.out.println("1");
		BasicDBObject document = new BasicDBObject();
		document.put("productID", productID);
		document.put("productName",productName);
		document.put("prodCate",prodCate);
		document.put("prodPrice",prodPrice);
		document.put("prodRetName",prodRetName);
		document.put("RetailerZip",RetailerZip);
		document.put("RetailerState",RetailerState);
		document.put("RetailerCity",RetailerCity);
		document.put("productOnSale",productOnSale);
		document.put("prodManfName",prodManfName);
		document.put("ManfRebate",ManfRebate);
		document.put("UserId",UserId);
		document.put("UserAge",UserAge);
		document.put("UserGender",UserGender);
		document.put("UserOccupation",UserOccupation);
		document.put("reviewRating", reviewRating);
		document.put("reviewDate",currDate);
		document.put("reviewText", reviewText);
		System.out.println("2");
		myReviews.insert(document);
		System.out.println("3");
		}
		catch(Exception e) {
			System.out.println("Error");
		}
	}

}
