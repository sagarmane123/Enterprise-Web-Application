import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class SubmitReview extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		try{
			//Get the values from the form
			MongoDBDataStoreUtilities inserReview = new MongoDBDataStoreUtilities();
			int productID = Integer.parseInt(request.getParameter("hiddenProdID"));
			String productName = request.getParameter("hiddenProdName");
			int reviewRating = Integer.parseInt(request.getParameter("reviewRating"));
			String reviewText = request.getParameter("reviewText");
			String prodCate = request.getParameter("hiddenProdCateg");
			String prodPrice = request.getParameter("hiddenProdPrice");
			String prodManfName = request.getParameter("hiddenManfName");
			String prodRetName = request.getParameter("hiddenManfName");
			String RetailerZip = request.getParameter("hiddenRetailorZip");
			String RetailerState = request.getParameter("hiddenRetailorState");
			String RetailerCity = request.getParameter("hiddenRetailorCity");
			String productOnSale = request.getParameter("hiddenProductOnSale");
			String ManfRebate = request.getParameter("hiddenManfRebate");
			String UserId = request.getParameter("userid");
			String UserAge = request.getParameter("userage");
			String UserGender = request.getParameter("gender");
			String UserOccupation = request.getParameter("userocc");
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
	        Date date = new Date();
	   		String currDate = dateFormat.format(date);
			
			
			
			ServletContext servletContext = request.getSession().getServletContext();
	        File fileName = new File(servletContext.getRealPath("productReview.txt"));
	        FileWriter fileStream = new FileWriter(fileName,true);
	        BufferedWriter buffWriter = new BufferedWriter(fileStream);
			
	        buffWriter.write(productID+"="+productID+","+reviewRating+","+reviewText);
	        inserReview.insertMongo(productID,productName,prodCate,prodPrice,prodRetName,
	        		RetailerZip,RetailerState,RetailerCity,productOnSale,prodManfName,ManfRebate,
	        		UserId,UserAge,UserGender,UserOccupation,reviewRating,currDate,reviewText);
	        buffWriter.write("\n");
	        buffWriter.close();
	        fileStream.close();
	        showPage(response, "Congratulation!!! Product Review has been Added Successfully");
								
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void showPage(HttpServletResponse response, String message)
		    throws ServletException, java.io.IOException {
		        response.setContentType("text/html");
		        java.io.PrintWriter pw = response.getWriter();
		        CommonUtilities cu  = new CommonUtilities();
		        String docType = 
		        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
		        "Transitional//EN\">\n";
		        pw.println(docType + "<html>"+
		            "<head>"+
		            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
		            "<title>Smart Portable - Add Review</title>"+
		            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
		            "</head>"+
		            "<body>"+
		            "<div id='container'>"+
		            cu.getHeader()+
		            "<nav>"+
		            "<ul>"+
		            "<li class='start selected'><a href='home.html'>Home</a></li>"+
		            "<li class=''><a href='login.html'>Sign Out</a></li>"+
		            "</ul>"+
		            "</nav>"+
		            "<div id=\"body\">"+
		            "<section id=\"content\">"+
		            "<p>" + message + "</p>"+
		            "<article>"+
		            "</section>"+
		            cu.getLeftNav()+
		            "<div class=\"clear\"></div>"+
		            "</div>"+	
		            cu.getFooter()+
		            "</div>"+		            
		            "</body>"+
		            "</html>");
		        pw.close();
		    }	
}