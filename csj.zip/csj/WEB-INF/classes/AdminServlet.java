import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class AdminServlet extends HttpServlet {

    protected void processPage(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
         response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ServletContext servletContext = request.getSession().getServletContext();
        File f = new File(servletContext.getRealPath("productDetailList.txt"));
        if(!f.exists()) { 
           
        
        SaxParserSmartPortableXMLdataStore sax = new SaxParserSmartPortableXMLdataStore(
				"C:/apache-tomcat-7.0.34/webapps/csj/ProductCatalog.xml");
		HashMap<String, Console> map = sax.consoles;
		
		PrintWriter pw = response.getWriter();
        File fileName = new File(servletContext.getRealPath("productDetailList.txt"));
        FileWriter fileStream = new FileWriter(fileName,true);
        BufferedWriter buffWriter = new BufferedWriter(fileStream);

		
        
		for (String s : map.keySet()) {
			  String productID = s;
		      String productName = map.get(s).getName();
		      String productDesc = map.get(s).getDesc();
		      String productComp = map.get(s).getCat();
		      String manfName = map.get(s).getManf();
		      String productPrice = map.get(s).getPrice();
		      productPrice = productPrice + ".00";
		      String manfReb = map.get(s).getmd();
		      String retDisc = map.get(s).getrd();
			buffWriter.write(productID+"="+productName+","+productDesc+","+productComp+","+manfName+","+productPrice+","+manfReb+","+retDisc);
	        buffWriter.write("\n");
		}
		buffWriter.close();
        fileStream.close();
        }
      BufferedReader buffReader = new BufferedReader(new FileReader(servletContext.getRealPath("productDetailList.txt")));
      HashMap<String,String> product = new HashMap<String,String>();
        String currentLine;
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Admin Portal</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            "<header>"+
            "<h1>Smart<span> Portable</span> Admin Portal</h1>"+
            "<h2>Online Store</h2>"+
            "</header>"+
			"<fieldset>"+
			"<legend align=\"center\">Product Details</legend><br>"+
			"</fieldset>"+
            "<form  id='deleteProduct' action='/csj/DeleteProductServlet' method='post'><table>"+
            "<tr>"+
            "<th>ProductID</th>"+
            "<th>Product Name</th>"+
            "<th>Description</th>"+
            "<th>Category</th>"+
            "<th>Manufacter Name</th>"+
            "<th>Price</th>"+
            "<th>Manufacter Rebate</th>"+
            "<th>Retailer Discount</th>"+
            "<th>Delete</th>"+
            "</tr>");
        while((currentLine =buffReader.readLine())!=null)
        {
            String [] prods = currentLine.split("=");
            String [] prodVars = prods[1].split(",");
            out.println("<tr>");
            out.println("<td>"+prods[0]+"</td>");
            out.println("<td>"+prodVars[0]+"</td>");
            out.println("<td>"+prodVars[1]+"</td>");
            out.println("<td>"+prodVars[2]+"</td>");
            out.println("<td>"+prodVars[3]+"</td>");
            out.println("<td>"+prodVars[4]+"</td>");
            out.println("<td>"+prodVars[5]+"</td>");
            out.println("<td>"+prodVars[6]+"</td>");
            out.println("<td><button onclick='/csj/DeleteProductServlet' name='prodID' id='prodID' value = '"+prods[0]+"'>Delete</button></td>");
            out.println("</tr>");
        }

        buffReader.close();
        out.println(
            "</table></form>"+
            "<a href='/csj/AddProduct.html' alt=\"Add Product\"><img src=\"images/add.png\" alt=\"Add Product\" style=\"width:50px;height:30px;\"></a>"+
            "</br></br>"+
            "<fieldset>"+
            "<legend align=\"center\">Update Product</legend>"+
            "<form method='post' action='/csj/UpdateProductServlet'>"+
            "<form id='updateProduct' action='/csj/UpdateProductServlet' method='post'>"+
            "<label for='prodID' >Enter Product ID</label><br>"+
            "<input type='text' name='prodID' id='prodID' maxlength='2' placeholder='Product ID'/><br><br>"+
            "<label for='updateColumnName' >Update Field:</label><br>"+
            "<select name='updateColumnName'>"+
            "<option value='prodName'>Name</option>"+
            "<option value='prodDes'>Description</option>"+
            "<option value='prodCat'>Category</option>"+
            "<option value='manfName'>Manufacter Name</option>"+
            "<option value='prodPrice'>Price</option>"+
            "<option value='manfRebate'>Manufacter Rebate</option>"+
            "<option value='retDiscount'>Retailer Discount</option>"+
            "</select><br><br>"+
			"<label for='updateValue' >New Value:</label><br>"+
            "<input type='text' name='updateValue' id='updateValue' maxlength='30'/><br><br>"+
            "<input type='submit' name='Submit' value='Submit' />"+
            "</form>"+
            "</fieldset>"+
            "</br></br>"+
            "<fieldset>"+
            "<a href='/csj/login.html'>Sign Out</a>"+
            "<br><a href='/csj/Inventory'>Inventory</a>"+
            "<br><a href='/csj/salesReport'>Sales Report</a>"+
            "</fieldset>"+
            "</div>"+
            "</body>"+
            "</html>");
    } 
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    }
}
