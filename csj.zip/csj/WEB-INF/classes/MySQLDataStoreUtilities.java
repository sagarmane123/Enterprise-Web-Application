import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import com.opencsv.CSVWriter;

public class MySQLDataStoreUtilities {

	public static  Statement stmt;
	public static  Connection conn ;
	
	public static void connectToMySQL(){
    	
        final String JDBC_DRIVER="com.mysql.jdbc.Driver";  
        final String DB_URL="jdbc:mysql://localhost:3306/smartportable?useSSL=false";
        final String USER = "root";
        final String PASS = "root";
       
	    try {
			Class.forName("com.mysql.jdbc.Driver");
		
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
	
			stmt = conn.createStatement();
	    } catch (Exception e) {
			System.out.println("*************ERROR in connecting mySQL DB *******************" + e);
			
		}
	   
    }
	
	public static void insertUser(User u){
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String insertIntoCustomerRegisterQuery = "INSERT INTO registration(username,password) "
			+ "VALUES (?,?);";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
			System.out.println("2");
			pst.setString(1,u.getName());
			pst.setString(2,u.getPassword());
			pst.execute();
			System.out.println("3");
			System.out.println(u.getName()+"  "+ u.getPassword());
			pst.close();
			
		} catch(Exception e){
			System.out.println("*************ERROR in insert user *******************");
		}
	}
	
	
	public static void insertProduct(int pid, String name, String price, String onsale, String manfreb){
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String insertIntoCustomerRegisterQuery = "INSERT INTO product "
			+ "VALUES (?,?,?,?,?,?);";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
			System.out.println("2");
			pst.setInt(1,pid);
			pst.setString(2,name);
			pst.setString(3,price);
			pst.setString(4,onsale);
			pst.setString(5,manfreb);
			pst.setInt(6,50);
			pst.execute();
			System.out.println("3");
			pst.close();
			
		} catch(Exception e){
			System.out.println("*************ERROR in insert product *******************");
		}
	}
	
	public static void insertSubProduct(){
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String s[] = {
			"insert into product values(111,'Pen Drive','50.0','yes','yes',45)",
			"insert into product values(112,'4GB Flash Drive','160.0','yes','yes',50)",
			"insert into product values(105,'QuietComfort 3 ear cushion kit','50.0','yes','yes',50)",
			"insert into product values(106,'Phiaton PS 210 BTNC','60.0','yes','yes',50)",
			"insert into product values(109,'Keyboard','80.0','yes','yes',90)",
			"insert into product values(110,'Adapter','160.0','yes','yes',50)",
			"insert into product values(107,'SD Card','60.0','yes','yes',80)",
			"insert into product values(108,'Bleutooth Headphone','600.0','yes','yes',60)",
			"insert into product values(101,'Replacement Band','50.0','yes','yes',50)",
			"insert into product values(102,'Watch Storage','60.0','yes','yes',35)",
			"insert into product values(103,'Speaker Stand','34.0','yes','yes',59)",
			"insert into product values(104,'Speaker Wire','25.0','yes','yes',25)"};
			for(int i=0;i<s.length;i++) {
			String insertIntoCustomerRegisterQuery = s[i];
			PreparedStatement pst = conn.prepareStatement(insertIntoCustomerRegisterQuery);
			pst.execute();
			pst.close();
			}
			System.out.println("3");
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in insert product *******************");
		}
	}
	
	public static void submitOrder(int orderID,String user,String currDate,String expDelvDate, String zip){
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String submitorder = "INSERT INTO orderDetails(id,username,currDate,expDate, zip) "
			+ "VALUES (?,?,?,?,?);";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(submitorder);
			System.out.println("2");
			pst.setInt(1,orderID);
			pst.setString(2,user);
			pst.setString(3,currDate);
			pst.setString(4,expDelvDate);
			pst.setString(5,zip);
			pst.execute();
			System.out.println("3");
			pst.close();
			
		} catch(Exception e){
			System.out.println("*************ERROR in submit order *******************");
		}
	}
	
	public static void productSold(String name,String currDate){
		try{
			System.out.println("00");
			
			Connection conn = getConnection();
			System.out.println("0");
			String submitorder = "INSERT INTO productSold(name,orderdate) "
			+ "VALUES (?,?);";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(submitorder);
			System.out.println("2");
			
			pst.setString(1,name);
			pst.setString(2,currDate);
			pst.execute();
			
			submitorder = "update product set available = available-1 where name = ?";
			pst = conn.prepareStatement(submitorder);
			pst.setString(1,name);
			pst.execute();
			System.out.println("3");
			pst.close();
			
		} catch(Exception e){
			System.out.println("*************ERROR in submit order *******************");
		}
	}
	
	public static void updateProduct(String type,String value, int id){
		try{
			System.out.println("00");
			
			Connection conn = getConnection();
			System.out.println("0");
			
			System.out.println("1");
			String updateProd="";
			if(type.equals("name"))		
			{updateProd = "update product set name = ? where pid = ?";}
			if(type.equals("price"))		
			{updateProd = "update product set price = ? where pid = ?";}
			PreparedStatement pst = conn.prepareStatement(updateProd);
			//pst.setString(1,type);
			pst.setString(1,value);
			pst.setInt(2,id);
			System.out.println(pst);
			pst.execute();
			System.out.println("3");
			pst.close();
			
		} catch(Exception e){
			System.out.println("*************ERROR in submit order *******************");
		}
	}
	
	public static void deleteOrder(int orderID){
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String deleteorder = "delete from orderDetails where id = ?";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(deleteorder);
			System.out.println("2");
			pst.setInt(1,orderID);
			pst.executeUpdate();
			System.out.println("3");
			pst.close();
			
		} catch(Exception e){
			System.out.println("*************ERROR in delete order *******************");
		}
	}
	
	public static void deleteProduct(int pid){
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String deleteorder = "delete from product where pid = ?";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(deleteorder);
			System.out.println("2");
			pst.setInt(1,pid);
			pst.executeUpdate();
			System.out.println("3");
			pst.close();
			
		} catch(Exception e){
			System.out.println("*************ERROR in delete order *******************");
		}
	}
	
	public static  HashMap<Integer, String> getZip(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "select  zip from orderDetails where zip is not null LIMIT 5;";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get zip *******************");
		}
		return hm;
	}
	
	public static  HashMap<Integer, String> getMostSoldProduct(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "SELECT name,COUNT(*) as count FROM productSold GROUP BY name order by count desc limit 5;";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get zip *******************");
		}
		return hm;
	}

	public static  HashMap<Integer, String> getLikeProduct(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "select distinct name from productSold limit 5;";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get zip *******************");
		}
		return hm;
	}
	
	public static  HashMap<Integer, String> getproduct(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "select  name,price,available from product order by available;";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1)+","+rs.getString(2)+","+rs.getString(3));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get zip *******************");
		}
		return hm;
	}
	
	public static  HashMap<Integer, String> getOnSaleproduct(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "select  name from product where onsale='yes';";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get zip *******************");
		}
		return hm;
	}
	
	public static  HashMap<Integer, String> getManfReb(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "select  name from product where manfreb='yes';";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get zip *******************");
		}
		return hm;
	}
	
	public static  HashMap<Integer, String> getSales(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "select name, sum(price)/count(*) as price,  count(*) as 'product sold',sum(price) as 'total sale'\r\n" + 
					"from(SELECT a.name,b.price from productSold a, product b where a.name = b.name) c group by name;";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1)+","+rs.getString(2)+","+rs.getString(3)+","+rs.getString(4));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get sales Report *******************");
		}
		return hm;
	}
	
	public static  HashMap<Integer, String> getDateSales(){
		HashMap<Integer,String> hm=new HashMap<Integer,String>(); 
		try{
			System.out.println("00");
			Connection conn = getConnection();
			System.out.println("0");
			String topzip = "select orderdate,  sum(price) as 'total sale'\r\n" + 
					"from(SELECT a.orderdate,b.price from productSold a, product b where a.name = b.name) c group by orderdate\r\n" + 
					";";
			System.out.println("1");
			PreparedStatement pst = conn.prepareStatement(topzip);
			System.out.println("2");
			
			ResultSet rs = pst.executeQuery();
			
			int i=1;
			while(rs.next()){  
			    System.out.println(rs.getString(1));  
			    hm.put(i++,rs.getString(1)+","+rs.getString(2));  
			   }  
			
			System.out.println("3");
			pst.close();
			
			
		} catch(Exception e){
			System.out.println("*************ERROR in get sales Report *******************");
		}
		return hm;
	}
	
    public static Connection getConnection() {
    	connectToMySQL();
    	return conn;
    }
   
    public StringBuffer getFrameWork(String term) {
    	Connection	connection = getConnection();
    ArrayList<String> list = new ArrayList<String>();
    StringBuffer sb = new StringBuffer();
    PreparedStatement ps = null;
    String data;
    try {
    ps = connection.prepareStatement("SELECT name,pid,price FROM product  WHERE name  LIKE ?");
    System.out.println("11");
            ps.setString(1, "%" + term + "%");
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                    data = rs.getString(1);
                    System.out.println(data);
                    list.add(data);
                    sb.append("<product>");
                    sb.append("<Id>" +  rs.getInt(2) + "</Id>");
                    sb.append("<Name>" + data + "</Name>");
                    sb.append("<Price>" +  rs.getString(3) + "</Price>");
                    sb.append("</product>");
            }
            System.out.println("done");
    } catch (Exception e) {
            System.out.println(e.getMessage());
    }
    return sb;
}
    public static void csvProductDetail() throws SQLException, IOException {
    	System.out.println("Conver done 1");
    	
    	Connection	connection = getConnection();
    	PreparedStatement ps = connection.prepareStatement("select state, avg(price) as avgPrice, count(*) as count, sum(price) as totalPrice from(select a.price,b.state from product a, productsold b where a.name=b.name) c group by state;\r\n" + 
    			"");
    	ResultSet rs = ps.executeQuery();
    	System.out.println("Conver done 2");
    	   
    	 /*          // convertToCsv ( rs ) ;
    	CSVWriter wr = new CSVWriter(new FileWriter("Report.csv"), ',');
    	wr.writeAll(rs, true);
    	wr.flush();
    	wr.close();*/
    	 PrintWriter pw = new PrintWriter(new File("C:\\apache-tomcat-7.0.34\\webapps\\csj\\productSoldByState.csv"));
         StringBuilder sb = new StringBuilder();
         sb.append("code");
         sb.append(',');
         sb.append("avg");
         sb.append(',');
         sb.append("count");
         sb.append(',');
         sb.append("total");
         sb.append('\n');
         //pw.write(sb.toString());
    	    System.out.println("Conver done");
        while (rs.next()) {

        	 sb.append(rs.getString(1));
             sb.append(',');
             sb.append(rs.getString(2));
             sb.append(',');
             sb.append(rs.getString(3));
             sb.append(',');
             sb.append(rs.getString(4));
             sb.append('\n');
            
        }
        pw.write(sb.toString());
        pw.close();
        System.out.println("done!");
        }
    
    public static void csvAVGProductSoldDetail() throws SQLException, IOException {
    	System.out.println("Conver done 1");
    	
    	Connection	connection = getConnection();
    	PreparedStatement ps = connection.prepareStatement("select state, avg(price) as count from(select a.price,b.state from product a, productsold b where a.name=b.name) c group by state;\r\n" + 
    			"");
    	ResultSet rs = ps.executeQuery();
    	System.out.println("Conver done 2");
    	   
    	 PrintWriter pw = new PrintWriter(new File("C:\\apache-tomcat-7.0.34\\webapps\\csj\\avgProductPriceSoldByState.csv"));
         StringBuilder sb = new StringBuilder();
         sb.append("code");
         sb.append(',');
         sb.append("count");
         sb.append('\n');
         //pw.write(sb.toString());
    	    System.out.println("Conver done");
        while (rs.next()) {

        	 sb.append(rs.getString(1));
             sb.append(',');
             sb.append(rs.getString(2));
             sb.append('\n');
            
        }
        pw.write(sb.toString());
        pw.close();
        System.out.println("done!");
        }
 
    }



