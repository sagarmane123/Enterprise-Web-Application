import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.text.DecimalFormat;
import java.lang.Math.*;

public class salesReport extends HttpServlet {
	protected void processPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter pw = response.getWriter();

		ServletContext sc = request.getSession().getServletContext();
		MySQLDataStoreUtilities mySQLStore = new MySQLDataStoreUtilities();
		HashMap<Integer,String> product=new HashMap<Integer,String>(); 
		product = mySQLStore.getSales();
		HashMap<Integer,String> dateSale=new HashMap<Integer,String>(); 
		dateSale = mySQLStore.getDateSales();
		String str = " ['Name', 'Total Sales'],\r\n";

		 for(Map.Entry m:product.entrySet()){  
	        	
	        	String[] res = ((String) m.getValue()).split(",");
	        	str += "['"+res[0]+"',"+Integer.parseInt(res[3])+"],";
		 }
		 System.out.println("+++++++++++++++\n");
		str = str.substring(0, str.length() - 1);
		 System.out.println(str);
		CommonUtilities cu  = new CommonUtilities();
		String docType = 
		        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
		        "Transitional//EN\">\n";
		        pw.println(docType + "<html>"+
		        		
		            "<head>"+
		            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
		            "<title>Smart Portable - Add Product</title>"+
		            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
		            "</head>"+
		            "<body>"+
		            "<script src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js\"></script>\r\n" + 
		            "  <script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>\r\n" + 
		            "  <script type=\"text/javascript\" src=\"./js/visualization-chart-script.js\"></script>"+
		            
		            "<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script> \r\n" + 
		            "<script>\r\n" + 
		            "   google.load(\"visualization\", \"1\", {packages:[\"corechart\"]});\r\n" + 
		            "   google.setOnLoadCallback(drawChart);\r\n" + 
		            "   function drawChart() {\r\n" + 
		            "    // Create and populate the data table.\r\n" + 
		            "    var data = google.visualization.arrayToDataTable(["+str+"]);\r\n" + 
		            "    var options = {\r\n" + 
		            "      title: 'Product Available'\r\n" + 
		            "    };\r\n" + 
		            "     // Create and draw the visualization.\r\n" + 
		            "    new google.visualization.BarChart(\r\n" + 
		            "      document.getElementById('my_chart')).draw(data, options);\r\n" + 
		            "  }\r\n" + 
		            "</script> "+
		            
		            
		            "<div id='container'>"+
		            cu.getHeader()+
		            "<nav>"+
		            "<ul>"+
		            "<li class='start selected'><a href='AdminServlet'>Home</a></li>"+
		            "<li class=''><a href='login.html'>Sign Out</a></li>"+
		            "</ul>"+
		            "</nav>"+
		            "<div id=\"body\">"+
		            "<section id=\"content\">"+
		            "<article>"+
		            "<legend align=\"center\">Sales Product</legend>"+
		            "<table>"+
		        "<tr>"
    			+ "<td>Name</td>"
    			+ "<td>Price</td>"
    			+ "<td>Total product sold</td>"
    			+ "<td>Total Sales</td>"+
    	"</tr>");
		        
		        for(Map.Entry m:product.entrySet()){  
		        	
		        	String[] res = ((String) m.getValue()).split(",");
	            	pw.println(
	            			"<tr>"
	            			+ "<td>"+res[0]+"</td>"
	            			+ "<td>"+res[1]+"</td>"
	            			+ "<td>"+res[2]+"</td>"
	            			+ "<td>"+res[3]+"</td>"+
	            	"</tr>"
	            			);  
	            	  } 
	            pw.println( "</table>"+
	            		 "<legend align=\"center\">Per Date Sales</legend>"+
	 		            "<table>"+
	 		        "<tr>"
	     			+ "<td>Date</td>"
	     			+ "<td>Total Sales</td>"+
	     	"</tr>");
	 		        
	 		        for(Map.Entry m:dateSale.entrySet()){  
	 		        	
	 		        	String[] res = ((String) m.getValue()).split(",");
	 	            	pw.println(
	 	            			"<tr>"
	 	            			+ "<td>"+res[0]+"</td>"
	 	            			+ "<td>"+res[1]+"</td>"+
	 	            	"</tr>"
	 	            			);  
	 	            	  } 
	 	            pw.println( "</table>"+
				            		  "<div id=\"my_chart\" style=\"width: 500px; height: 300px\">\r\n" + 
					            	  "</div>"+
		            "</section>"+
		            cu.getLeftNav()+
		            "<div class=\"clear\"></div>"+
		            "</div>"+	
		            cu.getFooter()+
		            "</div>"+		            
		            "</body>"+
		            "</html>");
		        pw.close();
}
	
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}
}
