import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class UpdateProductServlet extends HttpServlet 
{

    protected void updateProduct(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String userProdID = request.getParameter("prodID");
        String userUpdateKey = request.getParameter("updateColumnName");
        String userUpdateValue = request.getParameter("updateValue");
        System.out.println(userUpdateKey + " " + userUpdateValue);
        if(userProdID != null && userProdID.length() != 0) 
        {
            userProdID = userProdID.trim();
        }
        // create your filewriter and bufferedreader
        ServletContext sc =request.getSession().getServletContext();
        BufferedReader buffReader = new BufferedReader(new FileReader(sc.getRealPath("productDetailList.txt")));

        ArrayList<ProductDescription> elementList = new ArrayList<ProductDescription>();
        String readInput;
        while((readInput = buffReader.readLine()) != null)
        {
            ProductDescription pds = new ProductDescription();
            ProductDataSet.setData(readInput,pds);
            elementList.add(pds);
        }
        buffReader.close();

        for(ProductDescription element : elementList)
        {
            if(element.getID() == Integer.valueOf(userProdID))
            {
                if(userUpdateKey.equals("prodName"))
                    element.setProdName(userUpdateValue);

                if(userUpdateKey.equals("prodDes"))
                    element.setProdDesc(userUpdateValue);

                if(userUpdateKey.equals("prodCat"))
                    element.setProdCat(userUpdateValue);

                if(userUpdateKey.equals("manfName"))
                    element.setProdManfName(userUpdateValue);

                if(userUpdateKey.equals("prodPrice"))
                    element.setProdPrice(Double.valueOf(userUpdateValue));

                if(userUpdateKey.equals("manfRebate"))
                    element.setProdManfReb(userUpdateValue);

                if(userUpdateKey.equals("retDiscount"))
                    element.setProdRetDisc(userUpdateValue);
            }
        }

        PrintWriter writer = new PrintWriter(sc.getRealPath("productDetailList.txt"));
        ConvertDStoString cds = new ConvertDStoString();
        for(ProductDescription pds : elementList){
            String line = cds.convertdstostring(pds);
            System.out.println(line);
            writer.print(line);
            writer.print("\n");
        }
        writer.close();
        showPage(response, "Product has been Updated successfully");
    }

    protected void showPage(HttpServletResponse response, String message)
    throws ServletException, java.io.IOException {
        response.setContentType("text/html");
        java.io.PrintWriter out = response.getWriter();
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Game Center - Login</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            "<header>"+
            "<h1>Smart <span>Portable</span></h1>"+
            "<h2>Online Store</h2>"+
            "</header>"+
            "<h2>" + message + "</h2>"+
            "<br>"+
            "<a href='/csj/AdminServlet'><h3>Back to Admin Portal<h3></a>"+
            "</div>"+
            "</body>"+
            "</html>");
        out.close();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        updateProduct(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        updateProduct(request, response);
    }
}
