import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.text.DecimalFormat;
import java.lang.Math.*;

public class DealMatches extends HttpServlet {

	protected void processPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		ServletContext sc = request.getSession().getServletContext();
		BufferedReader buffReader = new BufferedReader(new FileReader(
				sc.getRealPath("productDetailList.txt")));
		
		BufferedReader deal = new BufferedReader(new FileReader(
				sc.getRealPath("DealMatches.txt")));

		ArrayList<ProductDescription> listx = new ArrayList<ProductDescription>();
		String readInput;
		while ((readInput = buffReader.readLine()) != null) {
			ProductDescription pds = new ProductDescription();
			ProductDataSet.setData(readInput, pds);
			listx.add(pds);
		}
		
		ArrayList<String> deallist = new ArrayList<String>();
		
		while ((readInput = deal.readLine()) != null) {
			deallist.add(readInput);
		}
		
		CommonUtilities cu = new CommonUtilities();
		String docType = "<!doctype html>\n";
		out.println(docType
				+ "<html>"
				+ "<head>"
				+ "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"
				+ "<title>Smart Portable</title>"
				+ "<link rel='stylesheet' href='styles.css' type='text/css' />"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">"
				+ "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>"
				+ "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>"
				+ "</head>"
				+ "<body>"
				+ "<div id='container'>"
				+ cu.getHeader()
				+ "<nav>"
				+ "<ul>"
				+ "<li class=''><a href='home.html'>Home</a></li>"
				+ "</ul>" + "</nav>" + "<div id='body'>"
				+ "<section id='content'>" + "<article class='expanded'>"
				+ "<h1>We beat our competitors in all fields</h1><br>"
				+"<h1>Price-Matched Guaranteed</h1>");
		if(deallist.size()>0) {
		for (int i = 0; i < 2; i++) {
			out.println(deallist.get(i));
			out.println("<br>");
		}
		}
		else {
			out.println("No Deal Matches<br>");
		}
		out.println("<table>");
		for (ProductDescription element : listx) {
			if ((element.name).equals("Flash Drive")) {
				String manfRebate = element.getProdManfReb();
				String retDiscount = element.getProdRetDisc();
				double originalPrice = element.getProdPrice();

				double manfDisc = Double
						.valueOf(manfRebate.replaceAll("%", ""));
				double retDisc = Double
						.valueOf(retDiscount.replaceAll("%", ""));
				double newPrice = (((100.00 - manfDisc) / 100.00) * originalPrice)
						* ((100.00 - retDisc) / 100.00);
				double manDispric = (((100.00 - manfDisc) / 100.00) * originalPrice);
				double disMan = (manfDisc / 100.00) * originalPrice;
				double disRetaAm = ((100.00 - manfDisc) / 100.00)
						* originalPrice * (retDisc / 100.00);
				double newDisc = disMan + disRetaAm;
				newPrice = Math.round(newPrice * 100) / 100;
				double discPercent = ((newDisc / originalPrice) * 100);
				int roundedDicPercent = (int) Math.round(discPercent);
				String img = "<img src =images/"
						+ element.getID()
						+ ".jpg width = '200' height = '200' alt = 'External Device'>";
				out.println("<tr>");
				out.println("<td>");
				out.println(img);
				out.println("</td>");
				out.println("<td>");
				out.println("<p> Specifications </p>");
				out.println("<b>Product Name: </b>" + element.getProdName()
						+ "<br>");
				out.println("<b>Manufacturer: </b>" + element.getProdManfName()
						+ "</br>");
				// out.println("<b>Description: </b>"+element.getProdDesc()+"</br>");
				out.println("<b>Price: </b>" + element.getProdPrice() + "</br>");
				out.println("<b>Discount: </b><span style='color:green'>"
						+ roundedDicPercent + "% Off</span></br>");
				out.println("<b>Discounted Price: </b>" + newPrice + "</br>");
				out.println("</td>");
				out.println("<td>");
				out.println("<form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>");
				out.println("<input type = 'hidden' name = 'hiddenProdID' value = '"
						+ element.getID() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdName' value = '"
						+ element.getProdName() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = '"
						+ element.getProdDesc() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '"
						+ newPrice + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = '"
						+ element.getProdCat() + "'>");
				out.println("<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>");
				out.println("</form>");
				out.println("<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>");
				out.println("<input type = 'hidden' name = 'hiddenProdID' value = '"
						+ element.getID() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdName' value = '"
						+ element.getProdName() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = '"
						+ element.getProdDesc() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '"
						+ newPrice + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = '"
						+ element.getProdCat() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenZip' value = '60616'>");
				out.println("<input type = 'hidden' name = 'hiddenState' value = 'IL'>");
				out.println("<input type = 'hidden' name = 'hiddenCity' value = 'Chicago'>");
				out.println("<input type = 'hidden' name = 'hiddenManfName' value = '"
						+ element.getProdManfName() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>");

				out.println("<input type = 'hidden' name = 'hiddenProductOnSale' value = 'yes'>");
				out.println("<input type = 'hidden' name = 'hiddenRetailorZip' value = '60616'>");
				out.println("<input type = 'hidden' name = 'hiddenRetailorCity' value = 'Chicago'>");
				out.println("<input type = 'hidden' name = 'hiddenRetailorState' value = 'IL'>");
				out.println("<input class = 'submit-button' type = 'submit'  value = 'Write Review'>");
				out.println("</form>");
				out.println("<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>");
				out.println("<input type = 'hidden' name = 'hiddenProdID' value = '"
						+ element.getID() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdName' value = '"
						+ element.getProdName() + "'>");
				out.println("<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>");
				out.println("</form>");
				out.println("</td>");
				out.println("</tr>");
			}
		}

		out.println("</table><br>"
				+ " </div>" + "</article>" + "</section>" + cu.getLeftNav()
				+ "<div class='clear'></div>" + "</div>" + cu.getFooter()
				+ "</div>" + "</body>" + "</html>");
		buffReader.close();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}
}
