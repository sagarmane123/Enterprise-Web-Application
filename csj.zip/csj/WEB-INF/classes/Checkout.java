/*
 * LoginServlet.java
 *
 */
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Checkout extends HttpServlet {

    protected void processPage(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        MySQLDataStoreUtilities mySQLStore = new MySQLDataStoreUtilities();
        HttpSession session = request.getSession();
        cart shoppingCart;
        shoppingCart = (cart) session.getAttribute("cart");
        session.setAttribute("cart", shoppingCart);
        List<String> productIDs = new ArrayList<String>();
        HashMap<String, List<String>> items = shoppingCart.getCartItems();
        Double total = 0.00;
        CommonUtilities cu = new CommonUtilities();
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
   		String currDate = dateFormat.format(date);
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
                    "<head>"+
                    "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
                    "<title>Smart Portable - Checkout</title>"+
                    "<link rel='stylesheet' href='styles.css' type='text/css' />"+
                    "</head>"+
                    "<body>"+
                    "<div id='container'>"+
                    cu.getHeader()+
                    "<center><h2>Place Order</h2></center>"+                         
                    " <form method='get' action='/csj/SubmitOrder'>"+
                    "<fieldset>"+
                    "<legend align=\"center\">Product information:</legend><br>"+
                    "<table>"+
                    "<tr>"+
                    "<th hidden>ProductID</th>"+
                    "<th>Product Name</th>"+
                    "<th>Price</th>"+
                "</tr>");
        
                for (Map.Entry<String, List<String>> entry : items.entrySet()) 
                {
                    String key = entry.getKey();
                    List<String> values = entry.getValue();
                    mySQLStore.productSold(values.get(1),currDate);
                    out.println("<tr>");
                    out.println("<td hidden><input type='text' name='productID' value= '"+values.get(0)+"' readonly> </td>");
                    out.println("<td><input type='text' name='productName' value= '"+values.get(1)+"' readonly> </td>");
                    out.println("<td><input type='text' name='productPrice' value= '"+values.get(2)+"' readonly> </td>");
                    out.println("</tr>");
                    total = total + Double.parseDouble(values.get(2));
                    productIDs.add(values.get(0));
                }
                String idList = productIDs.toString();
                String prodIDS = idList.substring(1, idList.length() - 1).replace(", ", ",");
        out.println(
            "<tr>"+
            "<td colspan ='3'>Total : "+total+"</td>"+
            "</tr>"+
            "</table>"+
            "</fieldset><br>"+
            "<fieldset>"+
            "<br><legend align=\"center\">Personal information:</legend>"+
            "<table>"+
            "<tr>"+
            "<td> First name: </td>"+
            "<td> <input type='text' name='firstName'> </td>"+
            "</tr>"+
            "<tr>"+
            "<td> Last name: </td>"+
            "<td> <input type='text' name='lastName'> </td>"+
            "</tr>"+
            "</tr>"+
            "<tr>"+
            "<td> Address: </td>"+
            "<td> <input type='text' name='address'> </td>"+
            "</tr>"+
            "<tr>"+
            "<td> Zip: </td>"+
            "<td> <input type='text' name='zip'> </td>"+
            "</tr>"+
            "<tr>"+
            "<td> Phone: </td>"+
            "<td> <input type='text' name='phoneNumber'> </td>"+
            "</tr>"+
            "<tr>"+
            "<td> CreditCard: </td>"+
            "<td> <input type='password' maxlength='16' name='creditcard'> </td>"+
            "</tr>"+
            "</table>"+
            "<br><br>"+
            "<input type='hidden' name='hiddenOrderTotal' value='"+total+"'>"+
            "<input type='hidden' name='hiddenProductIDs' value='"+prodIDS+"'>"+
            "<input class = 'submit-button' type = 'submit' name = 'orderButton' value = 'Place Order'>"+
            "</fieldset>"+
            "</form>"+
            cu.getFooter()+
            "</div>"+
            "</body>"+
            "</html>");
    } 

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        processPage(request, response);
    }
}
