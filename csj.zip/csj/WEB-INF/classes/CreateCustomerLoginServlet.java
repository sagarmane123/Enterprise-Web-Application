import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class CreateCustomerLoginServlet extends HttpServlet {

    protected void register(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
         response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String pwd = request.getParameter("password");

        ServletContext sc = request.getSession().getServletContext();
        File filename = new File(sc.getRealPath("logindetails.txt"));
        FileWriter filestream = new FileWriter(filename,true);
        BufferedWriter buffWriter = new BufferedWriter(filestream);
		if(name != null && name.trim().length() != 0 && username != null && username.trim().length() != 0 && pwd != null && pwd.trim().length() != 0){
        if(name != null && name.length() != 0) {
            name = name.trim();
        }
        if(username != null && username.length() != 0) {
            username = username.trim();
        }
        if(pwd != null && pwd.length() != 0) {
            pwd = pwd.trim();
        }

        buffWriter.write(username+":"+pwd+","+name);
        buffWriter.write("\n");
        buffWriter.close();
        filestream.close();
        showPage(response, "User "+name+" created successfully");
		}
		else
		{
			showPage(response, "Registration Failed!!! Please Enter Valid Details");
		}
    } 
    
    protected void showPage(HttpServletResponse response, String message)
    throws ServletException, java.io.IOException {
        response.setContentType("text/html");
        java.io.PrintWriter out = response.getWriter();
        CommonUtilities cu = new CommonUtilities();
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        out.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portable - Registration</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            cu.getHeader()+
            "<h2> Hello " +  message + "</h2>"+
            "<br>"+
			"<a href='SalesmanServlet'><h2>Home<h2></a>"+
            "</div>"+
			cu.getFooter()+
            "</body>"+
            "</html>");
        out.close();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        register(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        register(request, response);
    }
}
