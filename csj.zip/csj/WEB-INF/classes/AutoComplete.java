import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
 
//import org.json.JSONArray;
 
 
/**
 * Servlet implementation class AutoComplete
 */
 
public class AutoComplete extends HttpServlet {
 private static final long serialVersionUID = 1L;
 
    public AutoComplete() {
        super();
 
    }
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  ArrayList<String> al=new ArrayList<String>();
  try{
  DataSource ds=DataSource.getInstace();
      Connection conn=ds.getConnection();
      Statement stmt=conn.createStatement();
      String sql="select name from product";
      System.out.println(sql);
      ResultSet rs = stmt.executeQuery(sql);
      while(rs.next()){
       al.add(rs.getString("name"));
      }
      rs.close();
      stmt.close();
      conn.close();
  }catch(Exception e){
   e.printStackTrace();
  }
  System.out.println("1");
  System.out.println(al);
  //JSONArray json = new JSONArray(al);
  Gson gson = new GsonBuilder().create();
  JsonArray json = gson.toJsonTree(al).getAsJsonArray();
   System.out.println(json);
   System.out.println("2");
   response.setContentType("application/json");
         response.getWriter().print(json);
    
}
}
