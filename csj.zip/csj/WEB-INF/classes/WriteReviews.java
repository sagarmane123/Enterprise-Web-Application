import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class WriteReviews extends HttpServlet {
	String user = "";
	protected void processPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String prodID = request.getParameter("hiddenProdID");
		String prodName = request.getParameter("hiddenProdName");
		String prodDesc = request.getParameter("hiddenProdDesc");
		String prodPrice = request.getParameter("hiddenProdPrice");
		String prodCateg = request.getParameter("hiddenProdCateg");
		String prodManfName = request.getParameter("hiddenManfName");
		
		String ManfRebate = request.getParameter("hiddenManfRebate");
		String productOnSale = request.getParameter("hiddenProductOnSale");
		String ratailorZip = request.getParameter("hiddenRetailorZip");
		String ratailorState = request.getParameter("hiddenRetailorState");
		String ratailorCity = request.getParameter("hiddenRetailorCity");
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
   		String currDate = dateFormat.format(date);
   		
		ServletContext sc =request.getSession().getServletContext();
	    user = (String) sc.getAttribute("user");
		CommonUtilities cu = new CommonUtilities();
		String docType = "<!doctype html>\n";
		String img = "<img src = 'images/" + prodID
				+ ".jpg' width = '200' height = '200'>";
		out.println(docType
				+ "<html>"
				+ "<head>"
				+ "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"
				+ "<title>Smart Prtable - Review</title>"
				+ "<link rel='stylesheet' href='styles.css' type='text/css' />"
				+ "</head>"
				+ "<body>"
				+ "<div id='container'>"
				+ cu.getHeader()
				+ "<nav>"
				+ "<ul>"
				+ "<li class='start selected'><a href='home.html'>Home</a></li>"
				+ "</ul>"
				+ "</nav>"
				+ "<div id='body'>"
				+ "<section id='content'>"
				+ "<article>"
				+ "<h1>Product Reviews</h1>"
				+ "</article>"
				+ "<form method='get' action='/csj/SubmitReview'>"
				+ "<input type = 'hidden' name = 'hiddenProdID' value = '"
				+ prodID
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenProdName' value = '"
				+ prodName
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenProdDesc' value = '"
				+ prodDesc
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenProdPrice' value = '"
				+ prodPrice
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenProdCateg' value = '"
				+ prodCateg
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenManfName' value = '"
				+ prodManfName
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenManfRebate' value = '"
				+ ManfRebate
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenProductOnSale' value = '"
				+ productOnSale
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenRetailorZip' value = '"
				+ ratailorZip
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenRetailorState' value = '"
				+ ratailorState
				+ "'>"
				+ "<input type = 'hidden' name = 'hiddenRetailorCity' value = '"
				+ ratailorCity
				+ "'>"
				+ "<fieldset><br>"
				+ "<br><legend align=\"center\">Product information:</legend>"
				+ img
				+ "<table>"
				+ "<tr>"
				+ "<td> Product Model Name: </td>"
				+ "<td>"
				+ prodName
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Product Category: </td>"
				+ "<td>"
				+ prodCateg
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Product Price: </td>"
				+ "<td>"
				+ prodPrice
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Retailer Name: </td>"
				+ "<td>"
				+ prodManfName
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Manufacterer Name: </td>"
				+ "<td>"
				+ prodManfName
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Manufacterer Rebate: </td>"
				+ "<td>"
				+ ManfRebate
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Product On Sale: </td>"
				+ "<td>"
				+ productOnSale
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Retailor State: </td>"
				+ "<td>"
				+ ratailorState
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Retailor City: </td>"
				+ "<td>"
				+ ratailorCity
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Retailor Zip: </td>"
				+ "<td>"
				+ ratailorZip
				+ "</td>"
				+ "</tr>"
				+ "</table>"
				+ "</fieldset>"
				+ "<fieldset><br>"
				+ "<br><legend align=\"center\">Reviews:</legend>"
				+ "<table>"
				+ "<tr>"
				+ "<td> User Id: </td>"
				+ "<td><textarea name='userid' rows='1' cols='50'>" + user + "</textarea></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> User Age: </td>"
				+ "<td><textarea name='userage' rows='1' cols='50'> </textarea></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> User Occupation: </td>"
				+ "<td><textarea name='userocc' rows='1' cols='50'> </textarea></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Gender: </td>"
				+ "<td>"
				+ "<select name='gender'>"
				+ "<option value='Male' selected>Male</option>"
				+ "<option value='Female'>Female</option>"
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Review Rating: </td>"
				+ "<td>"
				+ "<select name='reviewRating'>"
				+ "<option value='1' selected>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"
				+ "</td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Review Text: </td>"
				+ "<td><textarea name='reviewText' rows='4' cols='50'> </textarea></td>"
				+ "</tr>"
				+ "<tr>"
				+ "<td> Date: </td>"
				+ "<td>"+ currDate + "</td>"
				+ "</tr>" + "</table>" + "<br><br>"
				+ "<input type='submit' value='Submit Review'>" + "</fieldset>"
				+ "</form>" + "</section>" + cu.getLeftNav()
				+ "<div class='clear'></div>" + "</div>" + cu.getFooter()
				+ "</div>" + "</body>" + "</html>");
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}
}
