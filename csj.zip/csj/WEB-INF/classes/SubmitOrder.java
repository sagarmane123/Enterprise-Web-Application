import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SubmitOrder extends HttpServlet {
	String user = "";
	String totalCost="";
	String address = "";
	String phone="";
	String zip="";
	static Random r = new Random();
	static int orderID = r.nextInt(999999);
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		try{
			MySQLDataStoreUtilities mySQLStore = new MySQLDataStoreUtilities();
		    ServletContext servletContext = request.getSession().getServletContext();
	        File fileName = new File(servletContext.getRealPath("PlacedOrder.txt"));
	        FileWriter fileStream = new FileWriter(fileName,true);
	        BufferedWriter buffWriter = new BufferedWriter(fileStream);
	        totalCost = request.getParameter("hiddenOrderTotal");
	        address = request.getParameter("address");
	        zip = request.getParameter("zip");
	        phone = request.getParameter("phoneNumber");
	        HttpSession session = request.getSession();
	        ServletContext sc =request.getSession().getServletContext();
	        user = (String) sc.getAttribute("user");
	        cart shoppingCart;
	        shoppingCart = (cart) session.getAttribute("cart");
	        session.setAttribute("cart", shoppingCart);
	        HashMap<String, List<String>> items = shoppingCart.getCartItems();
	        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
	        Date date = new Date();
	   		String currDate = dateFormat.format(date);

	   		Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());

	   		cal.add(Calendar.DATE, 14);  // add 14 days
	   		String expDelvDate = dateFormat.format(cal.getTime());
	        for (Map.Entry<String, List<String>> entry : items.entrySet()) 
            {
                String key = entry.getKey();
                List<String> values = entry.getValue();
            }
	        buffWriter.write(orderID+"="+user+","+currDate+","+expDelvDate);
            buffWriter.write("\n");
	        buffWriter.close();
	        fileStream.close();
	        mySQLStore.submitOrder(orderID, user, currDate, expDelvDate, zip);
	        showPage(response, "Congratulation!!! "+ user + " Order has been Placed Successfully");
	        session.removeAttribute("cart");
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected void showPage(HttpServletResponse response, String message)
		    throws ServletException, java.io.IOException {
		        response.setContentType("text/html");
		        java.io.PrintWriter pw = response.getWriter();
		        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		   		//get current date time with Date()
		   		Date date = new Date();
		   		String currDate = dateFormat.format(date);

		   		Calendar cal = Calendar.getInstance();
				cal.setTime(new Date());

		   		cal.add(Calendar.DATE, 14);  // add 14 days
		   		String expDelvDate = dateFormat.format(cal.getTime());

		   		
				
		        CommonUtilities cu  = new CommonUtilities();
		        String home = "<li class='start selected'><a href='home.html'>Home</a></li>";
		        if(user.equals("salesman")){
		        	home = "<li class='start selected'><a href='SalesmanServlet'>Home</a></li>";
		        }
		        String docType = 
		        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
		        "Transitional//EN\">\n";
		        pw.println(docType + "<html>"+
		            "<head>"+
		            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
		            "<title>Smart Portable - Add Product</title>"+
		            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
		            "</head>"+
		            "<body>"+
		            "<div id='container'>"+
		            cu.getHeader()+
		            "<nav>"+
		            "<ul>"+
		            home+
		            "<li class=''><a href='login.html'>Sign Out</a></li>"+
		            "</ul>"+
		            "</nav>"+
		            "<div id=\"body\">"+
		            "<section id=\"content\">"+
		            "<br><p>" + message + "</p>"+
		            "<legend align=\"center\">Order Information</legend>"+
		            "<table>" +
		            "<tr>" +
		            "<td> Order ID:" +
		            "</td>" +
		            "<td>" + orderID +
		            "</td>" +
		            "</tr>" +
		            "<tr>" +
		            "<td> User:" +
		            "</td>" +
		            "<td>" + user +
		            "</td>" +
		            "</tr>" +
		            "<tr>" +
		            "<td> Total Amount:" +
		            "</td>" +
		            "<td>" + totalCost +
		            "</td>" +
		            "</tr>" +
		            "<tr>" +
		            "<td> Delivery Address:" +
		            "</td>" +
		            "<td>" + address +
		            "</td>" +
		            "</tr>" +
		            "<tr>" +
		            "<td> Phone Number:" +
		            "</td>" +
		            "<td>" + phone +
		            "</td>" +
		            "</tr>" +
		            "<tr>" +
		            "<td> Order Date:" +
		            "</td>" +
		            "<td>" + currDate +
		            "</td>" +
		            "</tr>" +
		            "<tr>" +
		            "<td> Expected Delivery Date:" +
		            "</td>" +
		            "<td>" + expDelvDate +
		            "</td>" +
		            "</tr>" +
		            "</table>"+
		            "<article>"+
		            "</section>"+
		            cu.getLeftNav()+
		            "<div class=\"clear\"></div>"+
		            "</div>"+	
		            cu.getFooter()+
		            "</div>"+		            
		            "</body>"+
		            "</html>");
		        pw.close();
		    }	
}