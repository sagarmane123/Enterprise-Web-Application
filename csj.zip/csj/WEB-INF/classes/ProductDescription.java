import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ProductDescription{

    public  int id ;
    public  String name ;
    public  String desc ;
    public  String categ ;
    public  String manfName ;
    public  double price ;
    public  String manfReb ;
    public  String retDiscount ;
    public String retailer;
    public int retailerZip;
    public String retailerCity;
    public String retailerState;
    public YesNo productOnSale;

    public void setID(int id){
        this.id = id ;
    } 

    public void setProdName(String name){
        this.name = name ;
    }

    public void setProdDesc(String desc){
        this.desc = desc ;
    }

    public void setProdCat(String categ){
        this.categ = categ ;
    }

    public void setProdManfName(String manfName){
        this.manfName = manfName ;
    }

    public void setProdPrice(double price){
        this.price = price ;
    }

    public void setProdManfReb(String manfReb){
        this.manfReb = manfReb ;
    }

    public void setProdRetDisc(String retDiscount){
        this.retDiscount = retDiscount ;
    }    

    public int getID(){
        return id ;
    }

    public String getProdName(){
        return name ;
    }

    public String getProdDesc(){
        return desc ;
    }

    public String getProdCat(){
        return categ ;
    }

    public String getProdManfName(){
        return manfName ;
    }

    public double getProdPrice(){
        return price;
    }

    public String getProdManfReb(){
        return manfReb ;
    }

    public String getProdRetDisc(){
        return retDiscount ;
    } 
    
    public String getRetailer() {
		return retailer;
	}
	public void setRetailer(String retailer) {
		this.retailer = retailer;
	}
	
	public int getRetailerZip() {
		return retailerZip;
	}

	public void setRetailerZip(int retailerZip) {
		this.retailerZip = retailerZip;
	}

	public String getRetailerCity() {
		return retailerCity;
	}

	public void setRetailerCity(String retailerCity) {
		this.retailerCity = retailerCity;
	}

	public String getRetailerState() {
		return retailerState;
	}

	public void setRetailerState(String retailerState) {
		this.retailerState = retailerState;
	}
	
	public YesNo getProductOnSale() {
		return productOnSale;
	}

	public void setProductOnSale(YesNo productOnSale) {
		this.productOnSale = productOnSale;
	}
}
