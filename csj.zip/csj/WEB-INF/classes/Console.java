
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.List;


public class Console {
    String image;
    String name;
    String id;
    String desc;
    String cate;
    String price;
    String rd;
    String md;
    String manf;
    
    public Console(){
    	
    }
    public Console(String s) {
		/*
		 * Pattern is id|name|bday|age|course
		 */

		// initializer our tokenizer
		StringTokenizer st = new StringTokenizer(s, "|");
		// set the values
		this.setId(st.nextToken());
		this.setImage(st.nextToken());
		this.setname(st.nextToken());
		this.setDesc(st.nextToken());
		this.setcate(st.nextToken());
		this.setmanf(st.nextToken());
		this.setPrice(st.nextToken());
		this.setrd(st.nextToken());
		this.setmd(st.nextToken());

	}
    
void setId(String id) {
	this.id = id;
}

void setmanf(String manf) {
	this.manf = manf;
}

void setcate(String cate) {
	this.cate = cate;
}

void setImage(String image) {
	this.image = image;
}

void setname(String name) {
	this.name = name;
}

void setPrice(String price) {
	this.price = price;
}

void setmd(String md) {
	this.md = md;
}

void setrd(String rd) {
	this.rd = rd;
}

void setDesc(String desc) {
	this.desc = desc;
}

public String getID(){
	return id;
}

public String getName(){
	return name;
}

public String getDesc(){
	return desc;
}

public String getCat(){
	return cate;
}

public String getManf(){
	return manf;
}

public String getPrice(){
	return price;
}

public String getmd(){
	return md;
}

public String getrd(){
	return rd;
}



}
