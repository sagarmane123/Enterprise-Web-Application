import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ProductPlaceOrder{

    public  int id ;
    public  String name ;
    public  String price ;
    public  String date ;
    public  String ddate ;

    public void setID(int id){
        this.id = id ;
    } 

    public void setUserName(String name){
        this.name = name ;
    }

    public void setDate(String date){
        this.date = date ;
    }
    
    public void setDdate(String ddate){
        this.ddate = ddate ;
    }
    public void setProdPrice(String price){
        this.price = price ;
    }
    
    public int getProdID(){
        return id ;
    }

    public String getUserName(){
        return name ;
    }

    public String getProdPrice(){
        return price ;
    }
    
    public String getdate(){
        return date ;
    }
   
    public String getDdate(){
        return ddate ;
    }
}
