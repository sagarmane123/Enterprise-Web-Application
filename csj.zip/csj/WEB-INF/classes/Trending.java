import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.text.DecimalFormat;
import java.lang.Math.*;

public class Trending extends HttpServlet {

	protected void processPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		MySQLDataStoreUtilities mySQLStore = new MySQLDataStoreUtilities();
		ServletContext servletContext = request.getSession().getServletContext();
		 HttpSession session = request.getSession();
	        ServletContext sc =request.getSession().getServletContext();
	        response.setContentType("text/html");
	        java.io.PrintWriter pw = response.getWriter();
	        CommonUtilities cu  = new CommonUtilities();
	        HashMap<Integer,String> hm= new HashMap<Integer,String>(); 
	        hm= mySQLStore.getZip();
	        
	        HashMap<Integer,String> ps= new HashMap<Integer,String>(); 
	        ps= mySQLStore.getMostSoldProduct();
	        
	        HashMap<Integer,String> lp= new HashMap<Integer,String>(); 
	        lp= mySQLStore.getLikeProduct();
	        String docType = 
			        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
			        "Transitional//EN\">\n";
			        pw.println(docType + "<html>"+
			            "<head>"+
			            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
			            "<title>Smart Portable - Add Product</title>"+
			            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
			            "</head>"+
			            "<body>"+
			            "<div id='container'>"+
			            cu.getHeader()+
			           
			            "<div id=\"body\">"+
			            "<section id=\"content\">"+
			            "<article>"+
			            "<legend align=\"center\">Top 5 Zip</legend>"+
			            "<table>");
			            for(Map.Entry m:hm.entrySet()){  
			            	pw.println(
			            			"<tr><td>"+m.getValue()+
			            	"</td></tr>"
			            			);  
			            	  } 
			            pw.println( "</table>"+
			            "<legend align=\"center\">Top 5 Sold Product</legend>"+
			            "<table>");
			            for(Map.Entry m:ps.entrySet()){  
			            	pw.println(
			            			"<tr><td>"+m.getValue()+
			            	"</td></tr>"
			            			);  
			            	  } 
			            pw.println( "</table>"+
			            "<legend align=\"center\">Top 5 Like Product</legend>"+
			            "<table>");
			            for(Map.Entry m:lp.entrySet()){  
			            	pw.println(
			            			"<tr><td>"+m.getValue()+
			            	"</td></tr>"
			            			);  
			            	  } 
			            pw.println( "</table>");
			            pw.println("</article></section>"+
			            cu.getLeftNav()+
			            "<div class=\"clear\"></div>"+
			            "</div>"+	
			            cu.getFooter()+
			            "</div>"+		            
			            "</body>"+
			            "</html>");
			        pw.close();
			        
		
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}
}
