import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class AddProductServlet extends HttpServlet {

    protected void addProduct(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
         response.setContentType("text/html;charset=UTF-8");
        PrintWriter pw = response.getWriter();
        String productID = request.getParameter("productID");
        String productName = request.getParameter("productName");
        String productDesc = request.getParameter("productDesc");
        String productComp = request.getParameter("productComp");
        String manfName = request.getParameter("manfName");
        String productPrice = request.getParameter("productPrice");
        productPrice = productPrice + ".00";
        String manfReb = request.getParameter("manfReb");
        String retDisc = request.getParameter("retDisc");

        ServletContext servletContext = request.getSession().getServletContext();
        File fileName = new File(servletContext.getRealPath("productDetailList.txt"));
        FileWriter fileStream = new FileWriter(fileName,true);
        BufferedWriter buffWriter = new BufferedWriter(fileStream);

        if(productID != null && productID.length() != 0) {
            productID = productID.trim();
        }
        if(productName != null && productName.length() != 0) {
            productName = productName.trim();
        }
        if(productDesc != null && productDesc.length() != 0) {
            productDesc = productDesc.trim();
        }
         if(productComp != null && productComp.length() != 0) {
            productComp = productComp.trim();
        }
         if(manfName != null && manfName.length() != 0) {
            manfName = manfName.trim();
        }
         if(productPrice != null && productPrice.length() != 0) {
            productPrice = productPrice.trim();
        }
        if(manfReb != null && manfReb.length() != 0) {
            manfReb = manfReb.trim();
        }
        if(retDisc != null && retDisc.length() != 0) {
            retDisc = retDisc.trim();
        }

        buffWriter.write(productID+"="+productName+","+productDesc+","+productComp+","+manfName+","+productPrice+","+manfReb+","+retDisc);
        buffWriter.write("\n");
        buffWriter.close();
        fileStream.close();
        showPage(response, "Congratulation!!! Product has been Added Successfully");
    } 

    protected void showPage(HttpServletResponse response, String message)
    throws ServletException, java.io.IOException {
        response.setContentType("text/html");
        java.io.PrintWriter pw = response.getWriter();
        CommonUtilities cu  = new CommonUtilities();
        String docType = 
        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
        "Transitional//EN\">\n";
        pw.println(docType + "<html>"+
            "<head>"+
            "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
            "<title>Smart Portable - Add Product</title>"+
            "<link rel='stylesheet' href='styles.css' type='text/css' />"+
            "</head>"+
            "<body>"+
            "<div id='container'>"+
            cu.getHeader()+
            "<nav>"+
            "<ul>"+
            "<li class='start selected'><a href='AdminServlet'>Home</a></li>"+
            "<li class=''><a href='login.html'>Sign Out</a></li>"+
            "</ul>"+
            "</nav>"+
            "<div id=\"body\">"+
            "<section id=\"content\">"+
            "<p>" + message + "</p>"+
            "<article>"+
            "</section>"+
            cu.getAdminLeftNav()+
            "<div class=\"clear\"></div>"+
            "</div>"+	
            cu.getFooter()+
            "</div>"+		            
            "</body>"+
            "</html>");
        pw.close();
    }
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        addProduct(request, response);
    } 

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, java.io.IOException {
        addProduct(request, response);
    }
}
