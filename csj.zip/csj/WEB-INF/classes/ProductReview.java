import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ProductReview{

    public  int id ;
    public  String name ;
    public  String rate ;
    public  String rev ;

    public void setID(int id){
        this.id = id ;
    } 

    public void setProdName(String name){
        this.name = name ;
    }

    public void setProdRate(String rate){
        this.rate = rate ;
    }

    public void setProdRev(String rev){
        this.rev = rev ;
    }
    
    public int getProdID(){
        return id ;
    }

    public String getProdName(){
        return name ;
    }

    public String getProdRate(){
        return rate ;
    }

    public String getProdRev(){
        return rev ;
    }

}
