import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.text.DecimalFormat;
import java.lang.Math.*;

public class Headphones extends HttpServlet {

	protected void processPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		ServletContext sc = request.getSession().getServletContext();
		BufferedReader buffReader = new BufferedReader(new FileReader(
				sc.getRealPath("productDetailList.txt")));

		ArrayList<ProductDescription> listx = new ArrayList<ProductDescription>();
		String readInput;
		while ((readInput = buffReader.readLine()) != null) {
			ProductDescription pds = new ProductDescription();
			ProductDataSet.setData(readInput, pds);
			listx.add(pds);
		}
		CommonUtilities cu = new CommonUtilities();
		String docType = "<!doctype html>\n";
		out.println(docType
				+ "<html>"
				+ "<head>"
				+ "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"
				+ "<title>Smart Portable</title>"
				+ "<link rel='stylesheet' href='styles.css' type='text/css' />"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">"
				+ "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>"
				+ "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>"
				+ "</head>"
				+ "<body>"
				+ "<div id='container'>"
				+ cu.getHeader()
				+ "<nav>"
				+ "<ul>"
				+ "<li class=''><a href='home.html'>Home</a></li>"
				+ "<li class='start selected'><a href='#'>HEADPHONE</a></li>"
				+ "</ul>" + "</nav>" + "<div id='body'>"
				+ "<section id='content'>" + "<article class='expanded'>"
				+ "<h2>Models in Head Phones</h2>" + "<table>");
		for (ProductDescription element : listx) {
			if (element.getProdCat().equals("Headphone") || element.getProdCat().equals("Warranty Card")) {
				String manfRebate = element.getProdManfReb();
				String retDiscount = element.getProdRetDisc();
				double originalPrice = element.getProdPrice();

				double manfDisc = Double
						.valueOf(manfRebate.replaceAll("%", ""));
				double retDisc = Double
						.valueOf(retDiscount.replaceAll("%", ""));
				double newPrice = (((100.00 - manfDisc) / 100.00) * originalPrice)
						* ((100.00 - retDisc) / 100.00);
				double manDispric = (((100.00 - manfDisc) / 100.00) * originalPrice);
				double disMan = (manfDisc / 100.00) * originalPrice;
				double disRetaAm = ((100.00 - manfDisc) / 100.00)
						* originalPrice * (retDisc / 100.00);
				double newDisc = disMan + disRetaAm;
				newPrice = Math.round(newPrice * 100) / 100;
				double discPercent = ((newDisc / originalPrice) * 100);
				int roundedDicPercent = (int) Math.round(discPercent);
				String img = "<img src =images/"
						+ element.getID()
						+ ".jpg width = '200' height = '200' alt = 'Headphone'>";
				out.println("<tr>");
				out.println("<td>");
				out.println(img);
				out.println("</td>");
				out.println("<td>");
				out.println("<p> Specifications </p>");
				out.println("<b>Product Name: </b>" + element.getProdName()
						+ "<br>");
				out.println("<b>Manufacturer: </b>" + element.getProdManfName()
						+ "</br>");
				// out.println("<b>Description: </b>"+element.getProdDesc()+"</br>");
				out.println("<b>Price: </b>" + element.getProdPrice() + "</br>");
				out.println("<b>Discount: </b><span style='color:green'>"
						+ roundedDicPercent + "% Off</span></br>");
				out.println("<b>Discounted Price: </b>" + newPrice + "</br>");
				out.println("</td>");
				out.println("<td>");
				out.println("<form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>");
				out.println("<input type = 'hidden' name = 'hiddenProdID' value = '"
						+ element.getID() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdName' value = '"
						+ element.getProdName() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = '"
						+ element.getProdDesc() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '"
						+ newPrice + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = '"
						+ element.getProdCat() + "'>");
				out.println("<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>");
				out.println("</form>");
				out.println("<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>");
				out.println("<input type = 'hidden' name = 'hiddenProdID' value = '"
						+ element.getID() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdName' value = '"
						+ element.getProdName() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = '"
						+ element.getProdDesc() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '"
						+ newPrice + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = '"
						+ element.getProdCat() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenManfName' value = '"
						+ element.getProdManfName() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>");

				out.println("<input type = 'hidden' name = 'hiddenProductOnSale' value = 'yes'>");
				out.println("<input type = 'hidden' name = 'hiddenRetailorZip' value = '60616'>");
				out.println("<input type = 'hidden' name = 'hiddenRetailorCity' value = 'Chicago'>");
				out.println("<input type = 'hidden' name = 'hiddenRetailorState' value = 'IL'>");
				out.println("<input class = 'submit-button' type = 'submit'  value = 'Write Review'>");
				out.println("</form>");
				out.println("<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>");
				out.println("<input type = 'hidden' name = 'hiddenProdID' value = '"
						+ element.getID() + "'>");
				out.println("<input type = 'hidden' name = 'hiddenProdName' value = '"
						+ element.getProdName() + "'>");
				out.println("<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>");
				out.println("</form>");
				out.println("</td>");
				out.println("</tr>");
			}
		}

		out.println("</table><br>"
				+"<h2>Accessories</h2>"
				
				+"<div class=\"container\" style=\"width:500px;height:400px;\">"
				+ "<div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">"
				+ "<!-- Indicators -->"
				+ "<ol class=\"carousel-indicators\">"
				+ "<li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>"
				+ "<li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>"
				+ "</ol>"
				+

				"<!-- Wrapper for slides -->"
				+ "<div class=\"carousel-inner\" style=\"width:500px;height:400px;\"> "
				+

				"<div class=\"item active\" style=\"width:500px;height:300px;\">"
				+ "<img src=\"images/105.jpg\" alt=\"QuietComfort 3 ear cushion kit\" style=\"width:100%;height:300px;\">"
				+ "<div class=\"carousel-desc\">");

		out.println("<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>");
		out.println("<input type = 'hidden' name = 'hiddenProdID' value = '105'>");
		out.println("<input type = 'hidden' name = 'hiddenProdName' value = 'QuietComfort 3 ear cushion kit'>");
		out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = 'QuietComfort 3 ear cushion kit'>");
		out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '50'>");
		out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>");
		out.println("<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>");
		out.println("</form>");
		out.println("<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>");
		out.println("<input type = 'hidden' name = 'hiddenProdID' value = '105'>");
		out.println("<input type = 'hidden' name = 'hiddenProdName' value = 'QuietComfort 3 ear cushion kit'>");
		out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = 'QuietComfort 3 ear cushion kit'>");
		out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '50'>");
		out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>");
		out.println("<input type = 'hidden' name = 'hiddenManfName' value = 'Bose'>");
		out.println("<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>");

		out.println("<input type = 'hidden' name = 'hiddenProductOnSale' value = 'yes'>");
		out.println("<input type = 'hidden' name = 'hiddenRetailorZip' value = '60616'>");
		out.println("<input type = 'hidden' name = 'hiddenRetailorCity' value = 'Chicago'>");
		out.println("<input type = 'hidden' name = 'hiddenRetailorState' value = 'IL'>");
		out.println("<input class = 'submit-button' type = 'submit'  value = 'Write Review'>");
		out.println("</form>");
		out.println("<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>");
		out.println("<input type = 'hidden' name = 'hiddenProdID' value = '105'>");
		out.println("<input type = 'hidden' name = 'hiddenProdName' value = 'QuietComfort 3 ear cushion kit'>");
		out.println("<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>");
		out.println("</form></center>"
				+

				" </div>"
				+ " </div>"
				+

				"<div class=\"item\" style=\"width:500px;height:300px;\">"
				+ " <img src=\"images/106.jpg\" alt=\"Phiaton PS 210 BTNC\" style=\"width:100%;height:300px;\">"
				+ "<div class=\"carousel-desc\">");

		out.println("<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>");
		out.println("<input type = 'hidden' name = 'hiddenProdID' value = '106'>");
		out.println("<input type = 'hidden' name = 'hiddenProdName' value = 'Phiaton PS 210 BTNC'>");
		out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = 'Phiaton PS 210 BTNC'>");
		out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>");
		out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>");
		out.println("<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>");
		out.println("</form>");
		out.println("<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>");
		out.println("<input type = 'hidden' name = 'hiddenProdID' value = '106'>");
		out.println("<input type = 'hidden' name = 'hiddenProdName' value = 'Phiaton PS 210 BTNC'>");
		out.println("<input type = 'hidden' name = 'hiddenProdDesc' value = 'Phiaton PS 210 BTNC'>");
		out.println("<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>");
		out.println("<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>");
		out.println("<input type = 'hidden' name = 'hiddenManfName' value = 'Phiaton'>");
		out.println("<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>");

		out.println("<input type = 'hidden' name = 'hiddenProductOnSale' value = 'yes'>");
		out.println("<input type = 'hidden' name = 'hiddenRetailorZip' value = '60616'>");
		out.println("<input type = 'hidden' name = 'hiddenRetailorCity' value = 'Chicago'>");
		out.println("<input type = 'hidden' name = 'hiddenRetailorState' value = 'IL'>");
		out.println("<input class = 'submit-button' type = 'submit'  value = 'Write Review'>");
		out.println("</form>");
		out.println("<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>");
		out.println("<input type = 'hidden' name = 'hiddenProdID' value = '106'>");
		out.println("<input type = 'hidden' name = 'hiddenProdName' value = 'Phiaton PS 210 BTNC'>");
		out.println("<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>");
		out.println("</form></center>"
				+

				"</div>"
				+ " </div>"
				+

				"</div>"
				+

				" <!-- Left and right controls -->"
				+ " <a class=\"left carousel-control\" href=\"#myCarousel\" data-slide=\"prev\">"
				+ " <span class=\"glyphicon glyphicon-chevron-left\"></span>"
				+ " <span class=\"sr-only\">Previous</span>"
				+ " </a>"
				+ " <a class=\"right carousel-control\" href=\"#myCarousel\" data-slide=\"next\">"
				+ " <span class=\"glyphicon glyphicon-chevron-right\"></span>"
				+ " <span class=\"sr-only\">Next</span>" + " </a>" + " </div>"
				+ " </div>" + "</article>" + "</section>" + cu.getLeftNav()
				+ "<div class='clear'></div>" + "</div>" + cu.getFooter()
				+ "</div>" + "</body>" + "</html>");
		buffReader.close();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}
}
