
public class CommonUtilities {
	
	public String getHeader(){
	String header="<header><h1 style=\"color:#315ca0\">Smart <span>Portable</span></h1></header>";
	return header;
	}
	
	public String getFooter(){
		String footer = "<footer>" + 
        "<div class=\"footer-content\">"+
            "<ul>"+
            	"<li><h4>Get to Know uS</h4></li>"+
                "<li><a href=\"#\">About Us</a></li>"+
                "<li><a href=\"#\">Contact</a></li>"+
            "</ul>"+
            
            "<ul>"+
            	"<li><h4>Services</h4></li>"+
                "<li><a href=\"#\">See All Services</a></li>"+
            "</ul>"+
            
            "<ul class=\"endfooter\">"+
            	"<li><h4>Costumers Services  </h4></li>"+
                "<li><a href=\"#\">Return Policy</a></li>"+
            "</ul>"+
            
            "<div class=\"clear\"></div>"+
        "</div>"+
        "<div class=\"footer-bottom\">"+
            "<p>&copy; Smart Portables 2017 By Sagar Mane</p>"+
         "</div>"+
    "</footer>";
		
		return footer;
	}
	
	public String getLeftNav(){
		String leftNav = "<aside class=\"sidebar\">"+
	
            "<ul>"+	
               "<li>"+
                    "<h4>Shop By Brand</h4>"+
                    "<ul>"+
                    "<li class=\"start selected\"><a href=\"home.html\">Home</a></li>"+
					"<li class=\"\"><a href=\"SmartWatches\">Smart Watches</a></li>"+
					"<li><a href=\"Speakers\">Speakers</a></li>"+
					"<li><a href=\"Headphones\">Headphones</a></li>"+
					"<li><a href=\"Mobiles\">Mobiles</a></li>"+
					"<li><a href=\"Laptops\">Laptops</a></li>"+
					"<li><a href=\"ExternalDevices\">External Devices</a></li>"+
					"<li><a href=\"Trending\">Trending</a></li>"+
                    "</ul>"+
                "</li>"+
                
                "<li>"+
                    "<h4>About us</h4>"+
                    "<ul>"+
                        "<li class=\"text\">"+
                        	"<p style=\"margin: 0;\">Smart Portable website to buy different types of smart watches, laptops, headphones, mobiles at one place<a href=\"#\" class=\"readmore\">Read More &raquo;</a></p>"+
                        "</li>"+
                    "</ul>"+
                "</li>"+               
            "</ul>"+
		
        "</aside>";
      return leftNav;                       	
	}
	
	public String getAdminLeftNav(){

		String leftNav = "<aside class=\"sidebar\">"+
	
            "<ul>"+	  
                "<li>"+
                    "<h4>About us</h4>"+
                    "<ul>"+
                        "<li class=\"text\">"+
                        	"<p style=\"margin: 0;\">Smart Portable website to buy different types of smart watches, laptops, headphones, mobiles at one place<a href=\"#\" class=\"readmore\">Read More &raquo;</a></p>"+
                        "</li>"+
                    "</ul>"+
                "</li>"+               
            "</ul>"+
		
        "</aside>";
      return leftNav;                       	
	
	}
	
	public String getAccessory(){
		String acc= "<div class='container'>"+
				"<div class='col-xs-12'>"+       
				  "  <div class='carousel slide' id='myCarousel'>"+
				   "     <div class='carousel-inner'>"+
				    "        <div class='item active'>"+
				     "               <ul class='thumbnails'>"+
				      "                  <li class='col-sm-3'>"+
				    	"					<div class='fff'>"+
						"						<div class='thumbnail'>"+
						"							<a href='#'><img src='images/102.jpg'  style=\"width:250px;height:300px;\"></a>"+
						"						</div>"+
						"						<div class='caption'>"+
						"							<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '102'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Watch Storage'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Watch Storage'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Smart Watch'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form></center>"+
						"<center><form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '102'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Watch Storage'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Watch Storage'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Smart Watch'>"+
						"<input type = 'hidden' name = 'hiddenZip' value = '60616'>"+
						"<input type = 'hidden' name = 'hiddenState' value = 'IL'>"+
						"<input type = 'hidden' name = 'hiddenCity' value = 'Chicago'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'Elegance'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form></center>"+
						"<center><form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '102'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Watch Storage'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
												"</div>"+
				                           " </div>"+
				                       " </li>"+
				                        "<li class='col-sm-3'>"+
											"<div class='fff'>"+
												"<div class='thumbnail'>"+
													"<a href='#'><img src='images/101.jpg' style=\"width:250px;height:300px;\"></a>"+
												"</div>"+
												"<div class='caption'>"+
													"<center><form  class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '101'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Replacement Band'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Replacement Band'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '50'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Smart Watch'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form></center>"+
						"<center><form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '101'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Replacement Band'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Replacement Band'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '50'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Smart Watch'>"+
						"<input type = 'hidden' name = 'hiddenZip' value = '60616'>"+
						"<input type = 'hidden' name = 'hiddenState' value = 'IL'>"+
						"<input type = 'hidden' name = 'hiddenCity' value = 'Chicago'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'Mifa'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form></center>"+
						"<center><form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '101'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Replacement Band'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
												"</div>"+
				                            "</div>"+
				                       " </li>"+
				                       " <li class='col-sm-3'>"+
											"<div class='fff'>"+
												"<div class='thumbnail'>"+
													"<a href='#'><img src='images/103.jpg' style=\"width:250px;height:300px;\"></a>"+
											"	</div>"+
											"	<div class='caption'>"+
													"<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '103'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Speaker Stand'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Speaker Stand'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '34'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Speaker'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form>"+
						"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '103'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Speaker Stand'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Speaker Stand'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '34'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Speaker'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'Sansus'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form>"+
						"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '103'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Speaker Stand'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
										"		</div>"+
				                         "   </div>"+
				                        "</li>"+
				                       "         </ul>"+
				            "  </div>"+"<!-- /Slide1 --> "+
				            "<div class='item'>"+
				             "       <ul class='thumbnails'>"+
				              "          <li class='col-sm-3'>"+
								"			<div class='fff'>"+
								"				<div class='thumbnail'>"+
								"					<a href='#'><img src='images/105.jpg' style=\"width:250px;height:300px;\"></a>"+
								"				</div>"+
								"				<div class='caption'>"+
													"<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '105'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'QuietComfort 3 ear cushion kit'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'QuietComfort 3 ear cushion kit'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '50'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form>"+
						"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '105'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'QuietComfort 3 ear cushion kit'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'QuietComfort 3 ear cushion kit'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '50'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'Bose'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form>"+
						"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '105'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'QuietComfort 3 ear cushion kit'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
												"</div>"+
				                           " </div>"+
				                       " </li>"+
				                        "<li class='col-sm-3'>"+
										"	<div class='fff'>"+
										"		<div class='thumbnail'>"+
										"			<a href='#'><img src='images/106.jpg' style=\"width:250px;height:300px;\"></a>"+
										"		</div>"+
										"		<div class='caption'>"+
													"<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '106'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Phiaton PS 210 BTNC'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Phiaton PS 210 BTNC'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form>"+
						"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '106'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Phiaton PS 210 BTNC'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Phiaton PS 210 BTNC'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Headphone'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'Phiaton'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form>"+
						"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '106'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Phiaton PS 210 BTNC'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
								"				</div>"+
				                 "           </div>"+
				                  "      </li>"+
				                   "     <li class='col-sm-3'>"+
									"		<div class='fff'>"+
									"			<div class='thumbnail'>"+
									"				<a href='#'><img src='images/107.jpg' style=\"width:250px;height:300px;\"></a>"+
									"		</div>"+
										"		<div class='caption'>"+
													"<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '107'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'SD Card'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'SD Card'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Mobile'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form>"+
						"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '107'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'SD Card'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'SD Card'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '60'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Mobile'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'SandDisk'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form>"+
						"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '107'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'SD Card'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
								"				</div>"+
				                 "           </div>"+
				                  "      </li>"+
				                  
				          "          </ul>"+
				           "   </div>"+"<!-- /Slide2 --> "+
				            "<div class='item'>"+
				             "       <ul class='thumbnails'>"+
				              "          <li class='col-sm-3'>"+	
								"			<div class='fff'>"+
								"				<div class='thumbnail'>"+
								"					<a href='#'><img src='images/109.jpg' style=\"width:250px;height:300px;\"></a>"+
								"				</div>"+
								"				<div class='caption'>"+
													"<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '109'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Keyboard'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Keyboard'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '80'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Laptop'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form>"+
						"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '109'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Keyboard'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Keyboard'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '80'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Laptop'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'Sony'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form>"+
						"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '109'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Keyboard'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
							"					</div>"+
				             "               </div>"+
				              "          </li>"+
				               "         <li class='col-sm-3'>"+
								"			<div class='fff'>"+
								"				<div class='thumbnail'>"+
								"					<a href='#'><img src='images/110.jpg' style=\"width:250px;height:300px;\"></a>"+
								"				</div>"+
								"				<div class='caption'>"+
													"<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '110'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Adapter'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Adapter'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '160'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Laptop'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form>"+
						"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '110'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Adapter'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Adapter'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '160'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Laptop'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'Dell'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form>"+
						"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '110'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Adapter'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
							"					</div>"+
				             "               </div>"+
				              "          </li>"+
				             				                   "     <li class='col-sm-3'>"+
									"		<div class='fff'>"+
									"			<div class='thumbnail'>"+
									"				<a href='#'><img src='images/999.jpg' style=\"width:250px;height:300px;\"></a>"+
									"			</div>"+
									"			<div class='caption'>"+
													"<center><form class = 'submit-button' method = 'get' action = '/csj/AddToCartServlet'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '999'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Warranty Card'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Warranty Card'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '10'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Warranty Card'>"+
						"<input class = 'submit-button' type = 'submit' value = 'Add to Cart'>"+
						"</form>"+
						"<form id='writeReview' class = 'submit-button' method = 'get' action = '/csj/WriteReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '999'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Warranty Card'>"+
						"<input type = 'hidden' name = 'hiddenProdDesc' value = 'Warranty Card'>"+
						"<input type = 'hidden' name = 'hiddenProdPrice' value = '10'>"+
						"<input type = 'hidden' name = 'hiddenProdCateg' value = 'Warranty Card'>"+
						"<input type = 'hidden' name = 'hiddenManfName' value = 'All'>"+
						"<input type = 'hidden' name = 'hiddenManfRebate' value = 'yes'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'Write Review'>"+
						"</form>"+
						"<form class = 'submit-button' method = 'get' action = '/csj/ViewReviews'>"+
						"<input type = 'hidden' name = 'hiddenProdID' value = '999'>"+
						"<input type = 'hidden' name = 'hiddenProdName' value = 'Warranty Card'>"+
						"<input class = 'submit-button' type = 'submit'  value = 'View Reviews'>"+
						"</form></center>"+
									"			</div>"+
				                     "       </div>"+
				                      "  </li>"+
				                    "</ul>"+
				           "   </div>"+"<!-- /Slide3 --> "+
				     "   </div>"+
				        
				       
					
						"	<center><ul class='control-box pager'>"+
						"		<li><a data-slide='prev' href='#myCarousel' class=''><i class='glyphicon glyphicon-chevron-left'></i></a></li>"+
						"		<li><a data-slide='next' href='#myCarousel' class=''><i class='glyphicon glyphicon-chevron-right'></i></li>"+
					"		</ul></center>"+
					
					"   <!-- /.control-box -->   "+
				                              
				 "   </div>"+"<!-- /#myCarousel -->"+
				        
				"</div>"+"<!-- /.col-xs-12 -->    "+      

				"</div>"+"<!-- /.container -->";
		return acc;
	}
	}
	

