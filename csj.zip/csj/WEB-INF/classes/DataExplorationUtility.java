import java.io.*;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.servlet.*;
import javax.servlet.http.*;

public class  DataExplorationUtility extends HttpServlet {

protected void processRequest(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException, SQLException {

MySQLDataStoreUtilities mySQLStore = new MySQLDataStoreUtilities();
mySQLStore.csvProductDetail();

MongoDBDataStoreUtilities db = new MongoDBDataStoreUtilities();
HashMap<String, Integer> hm  = db.getdata();



//mySQLStore.csvAVGProductSoldDetail();
PrintWriter pw = response.getWriter();
try {
	CommonUtilities cu  = new CommonUtilities();
	String docType = 
	        "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 "+
	        "Transitional//EN\">\n";
	        pw.println(docType + 
	        		"    <head>\r\n" + 
	        		"<!-- Plotly.js -->\r\n" + 
	        		"<link rel='stylesheet' href='styles.css' type='text/css' />"+
	        		"        <script src=\"https://cdn.plot.ly/plotly-latest.min.js\"></script>\r\n" + 
	        		"        </head>\r\n" + 
	        		"<div id='container'>"+
	        		cu.getHeader()+
		            "<nav>"+
		            "<ul>"+
		            "<li class='start selected'><a href='AdminServlet'>Home</a></li>"+
		            "<li class=''><a href='login.html'>Sign Out</a></li>"+
		            "</ul>"+
		            "</nav>"+
	        		"        <body>\r\n" + 
	        		"        <!-- Plotly chart will be drawn inside this DIV -->\r\n" + 
	        		"        <div id=\"myDiv\"></div>\r\n" + 
	        		"		<div id=\"myDiv1\"></div>\r\n" + 
	        		"		<div id=\"myDiv2\"></div>\r\n" + 
	        		"        <script>\r\n" + 
	        		"Plotly.d3.csv('productSoldByState.csv', function(err, rows){\r\n" + 
	        		"      function unpack(rows, key) {\r\n" + 
	        		"          return rows.map(function(row) { return row[key]; });\r\n" + 
	        		"      }\r\n" + 
	        		"\r\n" + 
	        		"      var data = [{\r\n" + 
	        		"          type: 'choropleth',\r\n" + 
	        		"          locationmode: 'USA-states',\r\n" + 
	        		"          locations: unpack(rows, 'code'),\r\n" + 
	        		"          z: unpack(rows, 'count'),\r\n" + 
	        		"          text: unpack(rows, 'count'),\r\n" + 
	        		"          zmin: 0,\r\n" + 
	        		"          zmax: 50,\r\n" + 
	        		"          colorscale: [\r\n" + 
	        		"              [0, 'rgb(242,240,247)'], [0.2, 'rgb(218,218,235)'],\r\n" + 
	        		"              [0.4, 'rgb(188,189,220)'], [0.6, 'rgb(158,154,200)'],\r\n" + 
	        		"              [0.8, 'rgb(117,107,177)'], [1, 'rgb(84,39,143)']\r\n" + 
	        		"          ],\r\n" + 
	        		"          colorbar: {\r\n" + 
	        		"              title: 'Count',\r\n" + 
	        		"              thickness: 0.2\r\n" + 
	        		"          },\r\n" + 
	        		"          marker: {\r\n" + 
	        		"              line:{\r\n" + 
	        		"                  color: 'rgb(255,0,0)',\r\n" + 
	        		"                  width: 2\r\n" + 
	        		"              }\r\n" + 
	        		"          }\r\n" + 
	        		"      }];\r\n" + 
	        		"\r\n" + 
	        		"\r\n" + 
	        		"      var layout = {\r\n" + 
	        		"          title: 'Total Number of product bought by State',\r\n" + 
	        		"          geo:{\r\n" + 
	        		"              scope: 'usa',\r\n" + 
	        		"              showlakes: true,\r\n" + 
	        		"              lakecolor: 'rgb(255,0,0)'\r\n" + 
	        		"          }\r\n" + 
	        		"      };\r\n" + 
	        		"	  \r\n" + 
	        		"	  \r\n" + 
	        		"	  \r\n" + 
	        		"	  var data1 = [{\r\n" + 
	        		"          type: 'choropleth',\r\n" + 
	        		"          locationmode: 'USA-states',\r\n" + 
	        		"          locations: unpack(rows, 'code'),\r\n" + 
	        		"          z: unpack(rows, 'avg'),\r\n" + 
	        		"          text: unpack(rows, 'avg'),\r\n" + 
	        		"          zmin: 0,\r\n" + 
	        		"          zmax: 5000,\r\n" + 
	        		"          colorscale: [\r\n" + 
	        		"              [0, 'rgb(242,240,247)'], [0.2, 'rgb(218,218,235)'],\r\n" + 
	        		"              [0.4, 'rgb(188,189,220)'], [0.6, 'rgb(158,154,200)'],\r\n" + 
	        		"              [0.8, 'rgb(117,107,177)'], [1, 'rgb(84,39,143)']\r\n" + 
	        		"          ],\r\n" + 
	        		"          colorbar: {\r\n" + 
	        		"              title: 'USD',\r\n" + 
	        		"              thickness: 0.2\r\n" + 
	        		"          },\r\n" + 
	        		"          marker: {\r\n" + 
	        		"              line:{\r\n" + 
	        		"                  color: 'rgb(255,0,0)',\r\n" + 
	        		"                  width: 2\r\n" + 
	        		"              }\r\n" + 
	        		"          }\r\n" + 
	        		"      }];\r\n" + 
	        		"\r\n" + 
	        		"\r\n" + 
	        		"      var layout1 = {\r\n" + 
	        		"          title: 'Average product prices for products sold in every State',\r\n" + 
	        		"          geo:{\r\n" + 
	        		"              scope: 'usa',\r\n" + 
	        		"              showlakes: true,\r\n" + 
	        		"              lakecolor: 'rgb(255,255,255)'\r\n" + 
	        		"          }\r\n" + 
	        		"      };\r\n" + 
	        		"	  \r\n" + 
	        		"	  \r\n" + 
	        		" var data2 = [{\r\n" + 
	        		"          type: 'choropleth',\r\n" + 
	        		"          locationmode: 'USA-states',\r\n" + 
	        		"          locations: unpack(rows, 'code'),\r\n" + 
	        		"          z: unpack(rows, 'total'),\r\n" + 
	        		"          text: unpack(rows, 'total'),\r\n" + 
	        		"          zmin: 0,\r\n" + 
	        		"          zmax: 5000,\r\n" + 
	        		"          colorscale: [\r\n" + 
	        		"              [0, 'rgb(242,240,247)'], [0.2, 'rgb(218,218,235)'],\r\n" + 
	        		"              [0.4, 'rgb(188,189,220)'], [0.6, 'rgb(158,154,200)'],\r\n" + 
	        		"              [0.8, 'rgb(117,107,177)'], [1, 'rgb(84,39,143)']\r\n" + 
	        		"          ],\r\n" + 
	        		"          colorbar: {\r\n" + 
	        		"              title: 'USD',\r\n" + 
	        		"              thickness: 0.2\r\n" + 
	        		"          },\r\n" + 
	        		"          marker: {\r\n" + 
	        		"              line:{\r\n" + 
	        		"                  color: 'rgb(255,0,0)',\r\n" + 
	        		"                  width: 2\r\n" + 
	        		"              }\r\n" + 
	        		"          }\r\n" + 
	        		"      }];\r\n" + 
	        		"\r\n" + 
	        		"\r\n" + 
	        		"      var layout2 = {\r\n" + 
	        		"          title: 'Total product prices for products sold in every State',\r\n" + 
	        		"          geo:{\r\n" + 
	        		"              scope: 'usa',\r\n" + 
	        		"              showlakes: true,\r\n" + 
	        		"              lakecolor: 'rgb(255,255,255)'\r\n" + 
	        		"          }\r\n" + 
	        		"      };\r\n" + 
	        		"	  \r\n" + 
	        		"      Plotly.plot(myDiv, data, layout, {showLink: false});\r\n" + 
	        		"	  Plotly.plot(myDiv1, data1, layout1, {showLink: false});\r\n" + 
	        		"	  Plotly.plot(myDiv2, data2, layout2, {showLink: false});\r\n" + 
	        		"});" + 
	        		"        </script>\r\n" + 
	        		"        </body>\r\n" + 
	        		"</div>"
	           );
} finally {
pw.close();
}
}


@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
try {
	processRequest(request, response);
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}


}