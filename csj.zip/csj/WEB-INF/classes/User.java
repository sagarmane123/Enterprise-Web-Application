
public class User implements java.io.Serializable{
	private int id;
	private String name;
	private String address;
	private String credNo;
	private int cartCount;
	private String password;
	
	
	public User(String name, String password){
		this.name = name;
		this.password = password;
	}
	
	public User() {
		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
