import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class ViewReviews extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String prodID = request.getParameter("hiddenProdID");
		String prodName = request.getParameter("hiddenProdName");
		ServletContext sc = request.getSession().getServletContext();
		BufferedReader buffReader = new BufferedReader(new FileReader(
				sc.getRealPath("productReview.txt")));

		ArrayList<ProductReview> listx = new ArrayList<ProductReview>();
		String readInput;
		while ((readInput = buffReader.readLine()) != null) {
			ProductReview pds = new ProductReview();
			ProductDataSet.setData(readInput, pds);
			listx.add(pds);
		}
		String img = "<img src =images/" + prodID + ".jpg width = '200' height = '200'>";
		CommonUtilities cu = new CommonUtilities();
		String docType = 
		        "<!doctype html>\n";
		        out.println(docType +
		                "<html>"+
		                "<head>"+
		                "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"+
		                "<title>Smart Portable - Review</title>"+
		                "<link rel='stylesheet' href='styles.css' type='text/css' />"+
		                "</head>"+
		                "<body>"+
		                "<div id='container'>"+
		                cu.getHeader()+
		                "<nav>"+
		                "<ul>"+
		                "<li class=''><a href='home.html'>Home</a></li>"+
		                "</ul>"+
		                "</nav>"+
		                "<div id='body'>"+
		                "<section id='content'>"+
		                "<article class='expanded'>"+
		                "<h2>Review</h2>"+
		                img+
		                "<h4>"+prodName+"</h2>"+
		                "<table>");
		        for(ProductReview element : listx)
		        {
		            if(element.getProdID() == Integer.parseInt(prodID))
		            {
		                //String prodName = element.getProdName();
		                String prodRate = element.getProdRate();
		                String prodRev = element.getProdRev();
		                out.println("<tr>");
		                out.println("<td>");
		                //out.println("<b>Product Name: </b>"+prodName+"<br>");
		                out.println("<b>Product Rating: </b>"+prodRate+"</br>");
		                out.println("<b>Product Review: </b>"+prodRev+"</br>");
		                out.println("</td>");
		                out.println("</tr>");
		            }
		        }

		        out.println(
		            "</table>"+
		            "</article>"+
		            "</section>"+
		            cu.getLeftNav()+
		            "<div class='clear'></div>"+
		            "</div>"+
		            cu.getFooter()+
		            "</div>"+
		            "</body>"+
		            "</html>");
		    buffReader.close();
	}

}
