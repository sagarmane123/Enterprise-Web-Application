import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
public class ConvertDStoString {
	public String convertdstostring(ProductDescription pds){
		StringBuffer sb = new StringBuffer();
        sb.append(pds.getID());
        sb.append("=");
        sb.append(pds.getProdName());
        sb.append(",");
        sb.append(pds.getProdDesc());
        sb.append(",");
        sb.append(pds.getProdCat());
        sb.append(",");
        sb.append(pds.getProdManfName());
        sb.append(",");
        sb.append(pds.getProdPrice());
        sb.append(",");
        sb.append(pds.getProdManfReb());
        sb.append(",");
        sb.append(pds.getProdRetDisc());
        return sb.toString();
		
	}
	
	public String convertdstostring(ProductPlaceOrder pds){
		StringBuffer sb = new StringBuffer();
        sb.append(pds.getProdID());
        sb.append("=");
        sb.append(pds.getUserName());
        sb.append(",");
        sb.append(pds.getdate());
        sb.append(",");
        sb.append(pds.getDdate());
        return sb.toString();
		
	}
}
