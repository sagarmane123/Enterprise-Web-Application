
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class AJAXUtitliy {
	
	public static  Statement stmt;
	public static  Connection conn ;
	
	public static void connectToMySQL(){
    	
        final String JDBC_DRIVER="com.mysql.jdbc.Driver";  
        final String DB_URL="jdbc:mysql://localhost:3306/smartportable?useSSL=false";
        final String USER = "root";
        final String PASS = "root";
       
	    try {
			Class.forName("com.mysql.jdbc.Driver");
		
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
	
			stmt = conn.createStatement();
	    } catch (Exception e) {
			System.out.println("*************ERROR in connecting mySQL DB *******************" + e);
			
		}
	   
    }
	

    public static Connection getConnection() {
    	connectToMySQL();
    	return conn;
    }
   
    public StringBuffer getFrameWork(String term) {
    	Connection	connection = getConnection();
    ArrayList<String> list = new ArrayList<String>();
    StringBuffer sb = new StringBuffer();
    PreparedStatement ps = null;
    String data;
    try {
    ps = connection.prepareStatement("SELECT name,pid,price FROM product  WHERE name  LIKE ?");
    System.out.println("11");
            ps.setString(1, "%" + term + "%");
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                    data = rs.getString(1);
                    System.out.println(data);
                    list.add(data);
                    sb.append("<product>");
                    sb.append("<Id>" +  rs.getInt(2) + "</Id>");
                    sb.append("<Name>" + data + "</Name>");
                    sb.append("<Price>" +  rs.getString(3) + "</Price>");
                    sb.append("</product>");
            }
            System.out.println("done");
    } catch (Exception e) {
            System.out.println(e.getMessage());
    }
    return sb;
}
	
	
}
