import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class SalesmanServlet extends HttpServlet{
	
	protected void processPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		ServletContext sc = request.getSession().getServletContext();
		BufferedReader buffReader = new BufferedReader(new FileReader(
				sc.getRealPath("PlacedOrder.txt")));
		ArrayList<ProductPlaceOrder> listx = new ArrayList<ProductPlaceOrder>();
		String readInput;
		while ((readInput = buffReader.readLine()) != null) {
			ProductPlaceOrder pds = new ProductPlaceOrder();
			ProductDataSet.setData(readInput, pds);
			listx.add(pds);
		}
		CommonUtilities cu = new CommonUtilities();
		String docType = "<!doctype html>\n";
		out.println(docType
				+ "<html>"
				+ "<head>"
				+ "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />"
				+ "<title>Smart Portable</title>"
				+ "<link rel='stylesheet' href='styles.css' type='text/css' />"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">"
				+ "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>"
				+ "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>"
				+ "</head>"
				+ "<body>"
				+ "<div id='container'>"
				+ cu.getHeader()
				+ "<nav>"
				+ "<ul>"
				+ "<li class=''><a href='SalesmanServlet'>Home</a></li>"
				+ "<li class='start selected'><a href='customerLogin.html'>Create Customer Login</a></li>"
				+ "<li class=''><a href='login.html'>Sign Out</a></li>"
				+ "</ul>" + "</nav>" + "<div id='body'>"
				+ "<section id='content'>" + "<article class='expanded'>");
		if(listx.size()>0){
				out.println("<h2>Order Details</h2>" + "<table class=\"table\">"
				+ "<tr>"
				+"<td>Product ID</td>"
				+"<td>User Name</td>"
				+"<td>Order Placed Date</td>"
				+"<td>Expected Delivery Date</td>"
				+"<td>Delete</td>");
		
		for (ProductPlaceOrder element : listx) {
			
				String userName = element.getUserName();
				int prodId = element.getProdID();
				String date = element.getdate();
				String ddate = element.getDdate();
				out.println("<tr>");
				out.println("<td>");
				out.println(prodId);
				out.println("</td>");
				out.println("<td>");
				out.println(userName);
				out.println("</td>");
				out.println("<td>");
				out.println(date);
				out.println("</td>");
				out.println("<td>");
				out.println(ddate);
				out.println("</td>");
				out.println("<td><form method = 'get' action = 'DeleteOrderProductServlet'><input type='hidden' name='prodID' id='prodID' value='"+prodId+"'><input class = 'submit-button' type = 'submit' name = 'deleteButton' value = 'Delete'></form></td>");
				out.println("</tr>");			
		}
		
		out.println("<tr><td><form class = 'submit-button' method = 'post' action = 'CancelOrderServlet'>");
		out.println("<input class = 'submit-button' type = 'submit'  value = 'Cancel Order'>");
		out.println("</form></td></tr>");
		out.println("</table>");
		}
		else{
			out.println("<h2>Order Not Place</h2>");
		}
		out.println("</article>" + "</section>" + cu.getLeftNav()
				+ "<div class='clear'></div>" + "</div>" + cu.getFooter()
				+ "</div>" + "</body>" + "</html>");
		buffReader.close();
	}
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			java.io.IOException {
		processPage(request, response);
	}
}
